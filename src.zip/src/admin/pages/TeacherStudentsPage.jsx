// src/admin/pages/TeacherStudentsPage.jsx
import { useState, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import TeacherPasswordBar from "./TeacherPasswordBar";
import { createStudent, bulkUploadStudents, downloadTemplate } from "../api/studentsApi";

export default function TeacherStudentsPage() {
  const navigate = useNavigate();

  // --- single create ---
  const [single, setSingle] = useState({
    username: "",
    name: "",
    rollNo: "",
    className: "",
    year: "",
    department: "",
    password: "1234",
  });
  const [photo, setPhoto] = useState(null);

  // --- bulk upload ---
  const [xlsx, setXlsx] = useState(null);

  // --- ui ---
  const [loading, setLoading] = useState(false);
  const [ok, setOk] = useState("");
  const [err, setErr] = useState("");

  const onSingleChange = (e) => {
    const { name, value } = e.target;
    setSingle((s) => ({ ...s, [name]: value }));
  };

  const toErrText = (e) => {
    if (!e) return "Request failed";
    if (typeof e === "string") return e;
    // our axios interceptor throws Error(message) with .status
    const data = e?.response?.data;
    if (data) {
      if (typeof data === "string") return data;
      if (data.message) return data.message;
      try { return JSON.stringify(data); } catch {}
    }
    return e.message || "Request failed";
  };

  const handleCreate = async () => {
    setOk(""); setErr("");

    // minimal required fields
    const { username, name, rollNo, className, year, department } = single;
    if (!username || !name || !rollNo || !className || !year || !department) {
      setErr("Please fill all required fields."); return;
    }

    try {
      setLoading(true);
      // API handles multipart + face auto-register if photo is present
      await createStudent(
        {
          username: username.trim(),
          name: name.trim(),
          rollNo: rollNo.trim(),
          className: className.trim(),
          year: year.trim(),
          department: department.trim(),
          password: (single.password || "1234").trim(),
        },
        photo
      );

      const withPhoto = !!(photo && photo.size > 0);
      setOk(withPhoto
        ? "Student created. Face registration requested (photo uploaded)."
        : "Student created.");

      // reset fields
      setSingle({
        username: "",
        name: "",
        rollNo: "",
        className: "",
        year: "",
        department: "",
        password: "1234",
      });
      setPhoto(null);
    } catch (e) {
      setErr(toErrText(e));
    } finally {
      setLoading(false);
    }
  };

  const handleBulk = async () => {
    setOk(""); setErr("");
    if (!xlsx) { setErr("Please choose a .xlsx file"); return; }
    try {
      setLoading(true);
      const res = await bulkUploadStudents(xlsx);
      setOk(
        `Uploaded. Created: ${res?.createdCount ?? 0}. ${
          res?.skippedCount ? `Skipped: ${res.skippedCount}.` : ""
        }`
      );
      setXlsx(null);
    } catch (e) {
      setErr(toErrText(e));
    } finally {
      setLoading(false);
    }
  };

  const logout = useCallback(() => {
    localStorage.removeItem("attendance:user");
    localStorage.removeItem("attendance:lastRole");
    // keep teacherPass as-is; up to you. Removing could be:
    // localStorage.removeItem("attendance:teacherPass");
    navigate("/login", { replace: true });
  }, [navigate]);

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Students (Roster)</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <Link to="/admin" style={btnGhost} role="button">← Dashboard</Link>
            <button type="button" style={btnDanger} onClick={logout}>Logout</button>
          </div>
        </div>

        <TeacherPasswordBar />

        {/* Single create */}
        <div style={card}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <div style={badge}>Create</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>
              If you attach a photo, the backend will automatically register the student's face.
            </div>
          </div>

          {err && <p style={errorBox}>{String(err)}</p>}
          {ok && <p style={okBox}>{ok}</p>}

          <div style={grid2}>
            <Field label="Username (email) *">
              <input
                name="username"
                style={input}
                value={single.username}
                onChange={onSingleChange}
                placeholder="jane@college.edu"
                autoComplete="off"
              />
            </Field>
            <Field label="Name *">
              <input
                name="name"
                style={input}
                value={single.name}
                onChange={onSingleChange}
                placeholder="Jane Doe"
                autoComplete="off"
              />
            </Field>

            <Field label="Roll No *">
              <input
                name="rollNo"
                style={input}
                value={single.rollNo}
                onChange={onSingleChange}
                placeholder="22CS001"
                autoComplete="off"
              />
            </Field>
            <Field label="Class Name *">
              <input
                name="className"
                style={input}
                value={single.className}
                onChange={onSingleChange}
                placeholder="CS-A"
                autoComplete="off"
              />
            </Field>

            <Field label="Year *">
              <input
                name="year"
                style={input}
                value={single.year}
                onChange={onSingleChange}
                placeholder="2"
                autoComplete="off"
              />
            </Field>
            <Field label="Department *">
              <input
                name="department"
                style={input}
                value={single.department}
                onChange={onSingleChange}
                placeholder="CSE"
                autoComplete="off"
              />
            </Field>

            <Field label="Password (temp)">
              <input
                name="password"
                style={input}
                value={single.password}
                onChange={onSingleChange}
                autoComplete="new-password"
              />
            </Field>
            <Field label="Photo (optional)">
              <input
                type="file"
                accept="image/*"
                style={inputFile}
                onChange={(e) => setPhoto(e.target.files?.[0] || null)}
              />
              {!!photo && (
                <div style={{ marginTop: 6, fontSize: 12, color: "#94a3b8" }}>
                  Selected: <b>{photo.name}</b> ({Math.round(photo.size / 1024)} KB)
                </div>
              )}
            </Field>
          </div>

          <div style={{ marginTop: 10 }}>
            <button type="button" style={btnPrimary} onClick={handleCreate} disabled={loading}>
              {loading ? "Saving…" : "Create Student"}
            </button>
          </div>
        </div>

        {/* Bulk upload */}
        <div style={card}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <div style={badge}>Bulk</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>
              Excel (.xlsx) columns: <code>username</code>, <code>name</code>, <code>rollNo</code>,
              <code>className</code>, <code>year</code>, <code>department</code>. Optional:
              <code>password</code>, <code>photoBase64</code>.
            </div>
          </div>

          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input
              type="file"
              accept=".xlsx"
              style={inputFile}
              onChange={(e) => setXlsx(e.target.files?.[0] || null)}
            />
            <button type="button" style={btnGhost} onClick={handleBulk} disabled={loading || !xlsx}>
              {loading ? "Uploading…" : "Upload"}
            </button>
            <button type="button" style={btnGhost} onClick={downloadTemplate}>
              Download Template (CSV)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <div style={lbl}>{label}</div>
      {children}
    </div>
  );
}

/* styles */
const page   = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap   = { maxWidth: 1100, margin: "0 auto" };
const head   = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 };
const title  = { margin: 0, fontSize: 24, fontWeight: 800 };
const card   = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 14, boxShadow: "0 10px 22px rgba(0,0,0,.35)", marginBottom: 14 };
const badge  = { display: "inline-block", padding: "2px 8px", fontSize: 12, borderRadius: 999, background: "#1e293b", border: "1px solid #334155", color: "#cbd5e1" };
const grid2  = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 };
const lbl    = { display: "block", fontSize: 13, color: "#cbd5e1", marginBottom: 6 };
const input  = { width: "100%", height: 40, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: "0 10px" };
const inputFile = { ...input, paddingTop: 8 };
const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer" };
const btnGhost   = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer", textDecoration: "none", display: "inline-block" };
const btnDanger  = { padding: "10px 14px", borderRadius: 10, border: "1px solid #7f1d1d", background: "#450a0a", color: "#fecaca", cursor: "pointer" };
const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginBottom: 8, fontSize: 13 };
const okBox    = { background: "#0b3b18", border: "1px solid #14532d", color: "#bbf7d0", padding: "8px 10px", borderRadius: 10, marginBottom: 8, fontSize: 13 };
