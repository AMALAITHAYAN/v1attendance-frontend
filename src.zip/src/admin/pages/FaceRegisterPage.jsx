// src/superadmin/pages/FaceRegisterPage.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { registerStudentFace } from "../api/faceAdminApi";
import { getAdminUser } from "../utils/saAuth";
import AdminPasswordBar from "./AdminPasswordBar";

export default function FaceRegisterPage() {
  const navigate = useNavigate();
  const { id: paramId } = useParams();
  const user = getAdminUser();

  // redirect if not logged in
  useEffect(() => {
    if (!user) navigate("/login", { replace: true });
  }, [user, navigate]);

  const [studentId, setStudentId] = useState(paramId || "");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [resBody, setResBody] = useState(null);

  useEffect(() => {
    if (paramId) setStudentId(paramId);
  }, [paramId]);

  async function onSubmit(e) {
    e?.preventDefault?.();
    setErr("");
    setOk("");
    setResBody(null);

    const idNum = Number(String(studentId).trim());
    if (!idNum) {
      setErr("Student ID is required");
      return;
    }

    try {
      setLoading(true);
      const data = await registerStudentFace(idNum);
      setResBody(data);
      setOk("Face registration triggered.");
    } catch (e2) {
      setErr(e2?.message || "Failed to register face");
    } finally {
      setLoading(false);
    }
  }

  const prettyJson = useMemo(() => {
    try {
      return resBody ? JSON.stringify(resBody, null, 2) : "";
    } catch {
      return String(resBody ?? "");
    }
  }, [resBody]);

  const canSubmit = Boolean(String(studentId).trim()) && !loading;

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Register Student Face</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={btnGhost} onClick={() => navigate("/superadmin")}>
              ← Dashboard
            </button>
          </div>
        </div>

        <AdminPasswordBar />

        {err && <p style={errorBox}>{err}</p>}
        {ok && <p style={okBox}>{ok}</p>}

        <form onSubmit={onSubmit} style={card}>
          <div style={grid2}>
            <div>
              <div style={lbl}>Student ID *</div>
              <input
                inputMode="numeric"
                value={studentId}
                onChange={(e) =>
                  setStudentId(e.target.value.replace(/\D/g, ""))
                }
                placeholder="e.g., 101"
                style={input}
              />
              <div style={hint}>
                Uses <code>/api/admin/students/&lt;id&gt;/face/register</code>.
                The backend will build embeddings using the student's stored
                photo. If the student has no photo, the server should return a
                clear error (409).
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "end", gap: 8 }}>
              <button type="submit" style={btnPrimary} disabled={!canSubmit}>
                {loading ? "Registering…" : "Register Face"}
              </button>
              <button
                type="button"
                style={btnGhost}
                onClick={() => {
                  setStudentId("");
                  setErr("");
                  setOk("");
                  setResBody(null);
                }}
                disabled={loading}
              >
                Clear
              </button>
            </div>
          </div>
        </form>

        {resBody && (
          <div style={card}>
            <div style={{ marginBottom: 6, fontWeight: 800 }}>Result</div>
            <pre style={pre}>{prettyJson}</pre>
            <div style={{ marginTop: 8 }}>
              <button
                style={btnGhost}
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(prettyJson);
                    setOk("Copied to clipboard");
                    setTimeout(() => setOk(""), 1500);
                  } catch {
                    /* ignore */
                  }
                }}
              >
                Copy JSON
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* styles */
const page = {
  minHeight: "100vh",
  background:
    "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)",
  color: "#e2e8f0",
  padding: 24,
};
const wrap = { maxWidth: 900, margin: "0 auto" };
const head = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: 12,
};
const title = { margin: 0, fontSize: 24, fontWeight: 800 };

const card = {
  background: "#111827",
  border: "1px solid #243244",
  borderRadius: 14,
  padding: 14,
  boxShadow: "0 10px 22px rgba(0,0,0,.35)",
  marginBottom: 12,
};
const grid2 = { display: "grid", gridTemplateColumns: "1fr auto", gap: 10 };

const lbl = {
  display: "block",
  fontSize: 13,
  color: "#cbd5e1",
  marginBottom: 6,
};
const input = {
  width: "100%",
  height: 40,
  background: "#0b1220",
  border: "1px solid #2b3a55",
  color: "#e2e8f0",
  borderRadius: 10,
  padding: "0 10px",
};
const hint = { marginTop: 6, color: "#94a3b8", fontSize: 12 };

const pre = {
  margin: 0,
  whiteSpace: "pre-wrap",
  wordBreak: "break-word",
  fontFamily:
    "ui-monospace, SFMono-Regular, Menlo, monospace",
  background: "#0b1220",
  border: "1px solid #243244",
  borderRadius: 10,
  padding: 10,
  fontSize: 12,
};

const btnPrimary = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "none",
  background: "#2563eb",
  color: "white",
  fontWeight: 800,
  cursor: "pointer",
};
const btnGhost = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "1px solid #334155",
  background: "#0b1220",
  color: "#cbd5e1",
  cursor: "pointer",
};

const errorBox = {
  background: "#7f1d1d",
  color: "#fecaca",
  padding: "8px 10px",
  borderRadius: 10,
  marginTop: 6,
  fontSize: 13,
};
const okBox = {
  background: "#0b3b18",
  border: "1px solid #14532d",
  color: "#bbf7d0",
  padding: "8px 10px",
  borderRadius: 10,
  marginTop: 6,
  fontSize: 13,
};
