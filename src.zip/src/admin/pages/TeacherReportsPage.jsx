// src/admin/pages/TeacherReportsPage.jsx
import { useEffect, useMemo, useState, useCallback, Fragment } from "react";
import { Link, useNavigate } from "react-router-dom";
import TeacherPasswordBar from "./TeacherPasswordBar";
import {
  fetchTeacherSessions,
  fetchTeacherSessionSummary,
} from "../api/teacherReportApi";

export default function TeacherReportsPage() {
  const navigate = useNavigate();

  // defaults: last 30 days
  const now = useMemo(() => new Date(), []);
  const fromDefault = useMemo(() => {
    const d = new Date(now);
    d.setDate(d.getDate() - 30);
    return d;
  }, [now]);

  const [from, setFrom] = useState(toLocal(fromDefault));
  const [to, setTo] = useState(toLocal(now));
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [rows, setRows] = useState([]); // SessionBrief[]

  // inline summary cache: { [sessionId]: {present,total,percentage} }
  const [summaries, setSummaries] = useState({});
  const [openId, setOpenId] = useState(null);

  const quick = (days) => {
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - days);
    setFrom(toLocal(start));
    setTo(toLocal(end));
  };

  const load = useCallback(async () => {
    setErr("");
    setLoading(true);
    try {
      if (new Date(from) > new Date(to)) throw new Error("From must be before To");
      const list = await fetchTeacherSessions(toApi(from), toApi(to));
      setRows(list || []);
      setSummaries({});
      setOpenId(null);
    } catch (e) {
      setErr(e?.response?.data || e?.message || "Failed to load");
    } finally {
      setLoading(false);
    }
  }, [from, to]);

  const openSummary = async (id) => {
    if (openId === id) {
      setOpenId(null);
      return;
    }
    setOpenId(id);
    if (summaries[id]) return;
    try {
      const s = await fetchTeacherSessionSummary(id);
      const pct = s.total ? Math.round((s.present * 10000) / s.total) / 100 : 0;
      setSummaries((m) => ({ ...m, [id]: { ...s, percentage: pct } }));
    } catch (e) {
      setSummaries((m) => ({
        ...m,
        [id]: { error: e?.response?.data || e?.message || "Failed" },
      }));
    }
  };

  useEffect(() => {
    // auto-load on mount
    load();
  }, [load]);

  const logout = useCallback(() => {
    localStorage.removeItem("attendance:user");
    localStorage.removeItem("attendance:lastRole");
    navigate("/login", { replace: true });
  }, [navigate]);

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Teacher Reports</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <Link to="/admin" style={btnGhost} role="button">
              ← Dashboard
            </Link>
            <button type="button" style={btnDanger} onClick={logout}>
              Logout
            </button>
          </div>
        </div>

        <TeacherPasswordBar />

        <div style={cardPad}>
          <div style={grid3}>
            <Field label="From">
              <input
                type="datetime-local"
                style={input}
                value={from}
                onChange={(e) => setFrom(e.target.value)}
              />
            </Field>
            <Field label="To">
              <input
                type="datetime-local"
                style={input}
                value={to}
                onChange={(e) => setTo(e.target.value)}
              />
            </Field>
            <div style={{ display: "flex", gap: 8, alignItems: "end" }}>
              <button type="button" style={btnGhost} onClick={() => quick(7)}>
                Last 7d
              </button>
              <button type="button" style={btnGhost} onClick={() => quick(30)}>
                Last 30d
              </button>
              <button
                type="button"
                style={btnPrimary}
                onClick={load}
                disabled={loading}
              >
                {loading ? "Loading…" : "Load"}
              </button>
            </div>
          </div>
          {err && <p style={errorBox}>{String(err)}</p>}
        </div>

        <div style={card}>
          <table style={table}>
            <thead>
              <tr>
                <th style={th}>Subject</th>
                <th style={th}>Class</th>
                <th style={th}>Start</th>
                <th style={th}>End</th>
                <th style={th}></th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr>
                  <td style={td} colSpan={5}>
                    No sessions found.
                  </td>
                </tr>
              )}
              {rows.map((r) => (
                <Fragment key={r.id}>
                  <tr>
                    <td style={td}>{r.subject}</td>
                    <td style={td}>{r.className}</td>
                    <td style={td}>{fmt(r.startTime)}</td>
                    <td style={td}>{fmt(r.endTime)}</td>
                    <td style={td}>
                      <button
                        type="button"
                        style={btnGhost}
                        onClick={() => openSummary(r.id)}
                      >
                        {openId === r.id ? "Hide" : "Summary"}
                      </button>
                    </td>
                  </tr>
                  {openId === r.id && (
                    <tr>
                      <td style={{ ...td, background: "#0b1220" }} colSpan={5}>
                        <SessionSummaryRow data={summaries[r.id]} />
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function SessionSummaryRow({ data }) {
  if (!data) return <div>Loading summary…</div>;
  if (data.error) return <div style={errorBox}>{String(data.error)}</div>;
  const pct = data.percentage ?? 0;
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "200px 200px 1fr",
        gap: 12,
        alignItems: "center",
      }}
    >
      <div>
        <strong>Present:</strong> {data.present}
      </div>
      <div>
        <strong>Total Marks:</strong> {data.total}
      </div>
      <div style={barOuter} title={`${pct}%`}>
        <div
          style={{ ...barInner, width: `${Math.min(100, Math.max(0, pct))}%` }}
        />
      </div>
      <div style={{ fontSize: 12, color: "#94a3b8" }}>{pct}% attendance</div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <div style={lbl}>{label}</div>
      {children}
    </div>
  );
}
function toLocal(d) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`;
}
function toApi(localVal) {
  return localVal.length === 16 ? `${localVal}:00` : localVal;
}
function fmt(isoLocal) {
  // backend sends ISO_LOCAL_DATE_TIME; render nicely
  try {
    const d = new Date(isoLocal.replace(" ", "T"));
    return d.toLocaleString();
  } catch {
    return isoLocal;
  }
}

/* styles */
const page = {
  minHeight: "100vh",
  background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)",
  color: "#e2e8f0",
  padding: 24,
};
const wrap = { maxWidth: 1100, margin: "0 auto" };
const head = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: 10,
};
const title = { margin: 0, fontSize: 24, fontWeight: 800 };

const card = {
  background: "#111827",
  border: "1px solid #243244",
  borderRadius: 14,
  padding: 0,
  boxShadow: "0 10px 22px rgba(0,0,0,.35)",
  marginTop: 10,
};
const cardPad = { ...card, padding: 12, marginTop: 0 };

const grid3 = { display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: 10 };
const lbl = { display: "block", fontSize: 13, color: "#cbd5e1", marginBottom: 6 };
const input = {
  width: "100%",
  height: 40,
  background: "#0b1220",
  border: "1px solid #2b3a55",
  color: "#e2e8f0",
  borderRadius: 10,
  padding: "0 10px",
};

const table = { width: "100%", borderCollapse: "collapse" };
const th = {
  textAlign: "left",
  fontWeight: 700,
  fontSize: 13,
  color: "#cbd5e1",
  padding: "12px 12px",
  borderBottom: "1px solid #243244",
};
const td = {
  padding: "12px 12px",
  borderBottom: "1px solid #1e293b",
  fontSize: 14,
};

const barOuter = {
  height: 10,
  background: "#0b1220",
  border: "1px solid #2b3a55",
  borderRadius: 999,
  overflow: "hidden",
  gridColumn: "1 / span 2",
};
const barInner = { height: "100%", background: "#2563eb" };

const btnPrimary = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "none",
  background: "#2563eb",
  color: "white",
  fontWeight: 800,
  cursor: "pointer",
  boxShadow: "0 8px 18px rgba(37,99,235,.35)",
};
const btnGhost = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "1px solid #334155",
  background: "#0b1220",
  color: "#cbd5e1",
  cursor: "pointer",
  textDecoration: "none",
  display: "inline-block",
};
const btnDanger = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "1px solid #7f1d1d",
  background: "#450a0a",
  color: "#fecaca",
  cursor: "pointer",
};
const errorBox = {
  background: "#7f1d1d",
  color: "#fecaca",
  padding: "8px 10px",
  borderRadius: 10,
  marginTop: 6,
  fontSize: 13,
};
