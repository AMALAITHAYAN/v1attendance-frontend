// src/admin/pages/TeacherPasswordBar.jsx
import { useEffect, useState, useCallback } from "react";
import { getTeacherUser, getTeacherPass, setTeacherPass } from "../utils/teacherAuth";

export default function TeacherPasswordBar() {
  const user = getTeacherUser(); // { username, role: "TEACHER" } | null
  const [show, setShow] = useState(false);
  const [pass, setPass] = useState("");

  // Initialize from storage once
  useEffect(() => {
    try { setPass(getTeacherPass() || ""); } catch {}
  }, []);

  // Auto-save to avoid missing headers on next API call
  const onChange = useCallback((e) => {
    const v = e.target.value ?? "";
    setPass(v);
    setTeacherPass(v);
  }, []);

  // Optional explicit save (kept for UX)
  const save = useCallback(() => setTeacherPass(pass ?? ""), [pass]);

  const disabled = !user?.username;

  return (
    <div style={bar}>
      <div style={{ fontSize: 13, color: "#94a3b8" }}>Teacher</div>
      <div style={{ fontWeight: 700, minWidth: 160 }}>
        {user?.username || "— not logged in —"}
      </div>

      <div style={{ flex: 1 }} />

      <input
        type={show ? "text" : "password"}
        placeholder="password"
        value={pass}
        onChange={onChange}
        style={{ ...input, opacity: disabled ? 0.6 : 1 }}
        disabled={disabled}
        autoComplete="current-password"
      />
      <button
        type="button"
        style={btnGhost}
        onClick={() => setShow((s) => !s)}
        disabled={disabled}
      >
        {show ? "Hide" : "Show"}
      </button>
      <button type="button" style={btnPrimary} onClick={save} disabled={disabled}>
        Save
      </button>
    </div>
  );
}

const bar = {
  display: "flex",
  gap: 10,
  alignItems: "center",
  background: "#0b1220",
  border: "1px solid #243244",
  borderRadius: 12,
  padding: 10,
  marginBottom: 12,
};
const input = {
  width: 340,
  height: 40,
  background: "#0b1220",
  border: "1px solid #2b3a55",
  color: "#e2e8f0",
  borderRadius: 10,
  padding: "0 10px",
};
const btnPrimary = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "none",
  background: "#2563eb",
  color: "white",
  fontWeight: 800,
  cursor: "pointer",
};
const btnGhost = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "1px solid #334155",
  background: "#0b1220",
  color: "#cbd5e1",
  cursor: "pointer",
};
