// src/admin/pages/ActiveSessionPage.jsx
import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getTeacherUser, setTeacherPassword } from "../utils/teacherAuth";
import { fetchCurrentQrToken } from "../api/qrsApi";
import { stopSession, fetchSessionSummary, fetchSessionById } from "../api/sessionsApi"; // ⬅️ add fetchSessionById
import TeacherPasswordBar from "./TeacherPasswordBar";
import ManualMarkDialog from "./ManualMarkDialog";
import QRCode from "qrcode";

export default function ActiveSessionPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const user = getTeacherUser();

  const [token, setToken] = useState("");
  const [lastUpdated, setLastUpdated] = useState(0);
  const [expiresAt, setExpiresAt] = useState(0);
  const [countdown, setCountdown] = useState(0);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");

  const [showManual, setShowManual] = useState(false);

  const [present, setPresent] = useState(0);
  const [total, setTotal] = useState(0);
  const countsTimerRef = useRef(null);

  const [confirmStop, setConfirmStop] = useState(false);
  const [stopping, setStopping] = useState(false);

  // NEW: session + “is QR enabled?” flag
  const [qrEnabled, setQrEnabled] = useState(true);

  const canvasRef = useRef(null);
  const refreshTimerRef = useRef(null);
  const tickTimerRef = useRef(null);

  useEffect(() => {
    if (!user) navigate("/login", { replace: true });
  }, [user, navigate]);

  useEffect(() => {
    return () => {
      if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
      if (tickTimerRef.current) clearInterval(tickTimerRef.current);
      if (countsTimerRef.current) clearInterval(countsTimerRef.current);
    };
  }, []);

  const logout = () => {
    localStorage.removeItem("attendance:user");
    setTeacherPassword("");
    navigate("/login", { replace: true });
  };

  const parseJwt = (jwt) => {
    try {
      const payload = jwt.split(".")[1];
      if (!payload) return null;
      const base = payload.replace(/-/g, "+").replace(/_/g, "/");
      const json = decodeURIComponent(
        atob(base)
          .split("")
          .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
          .join("")
      );
      return JSON.parse(json);
    } catch {
      return null;
    }
  };

  const scheduleTick = (expiresMs) => {
    if (tickTimerRef.current) clearInterval(tickTimerRef.current);
    tickTimerRef.current = setInterval(() => {
      setCountdown(Math.max(0, expiresMs - Date.now()));
    }, 200);
  };

  const scheduleRefresh = (expiresMs) => {
    const delay = Math.max(500, expiresMs - Date.now() - 200);
    if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
    refreshTimerRef.current = setTimeout(() => {
      void loadToken();
    }, delay);
  };

  const drawQR = async (val) => {
    if (!canvasRef.current) return;
    try {
      await QRCode.toCanvas(canvasRef.current, val || "NO_TOKEN", {
        width: 320,
        margin: 1,
      });
    } catch (e) {
      console.error("QR draw failed", e);
    }
  };

  const clearQRCanvas = () => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, c.width || 320, c.height || 320);
  };

  const loadToken = async () => {
    if (!qrEnabled) return; // guard
    try {
      setErr("");
      setLoading(true);

      const t = await fetchCurrentQrToken(id);
      setToken(t || "");
      setLastUpdated(Date.now());

      // compute expiry from JWT if present; otherwise default 5s
      const payload = t ? parseJwt(t) : null;
      const expSec = payload?.exp;
      let expMs;
      if (expSec && Number.isFinite(expSec)) {
        expMs = expSec * 1000;
      } else {
        expMs = Date.now() + 5000;
      }

      setExpiresAt(expMs);
      setCountdown(Math.max(0, expMs - Date.now()));
      scheduleTick(expMs);
      scheduleRefresh(expMs);

      await drawQR(t);
    } catch (e) {
      if (e.status === 403) {
        setErr("Forbidden: TEACHER required. Please re-login.");
        navigate("/login", { replace: true });
      } else {
        setErr(e.message || "Failed to load QR token");
      }
    } finally {
      setLoading(false);
    }
  };

  const loadCounts = async () => {
    try {
      const sum = await fetchSessionSummary(id); // { sessionId, present, total }
      setPresent(sum?.present ?? 0);
      setTotal(sum?.total ?? 0);
    } catch (e) {
      console.warn("Counts fetch failed", e?.message);
    }
  };

  // NEW: fetch session meta just to know whether QR is enabled
  const loadSessionMeta = async () => {
    try {
      const s = await fetchSessionById(id); // should return { flow: [...] }
      const enabled = Array.isArray(s?.flow) && s.flow.includes("QR");
      setQrEnabled(enabled);
      if (!enabled) {
        // stop timers and clear any old QR
        if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
        if (tickTimerRef.current) clearInterval(tickTimerRef.current);
        setToken("");
        setExpiresAt(0);
        setCountdown(0);
        clearQRCanvas();
      }
    } catch {
      // If meta fetch fails, fall back to old behavior (QR visible)
      setQrEnabled(true);
    }
  };

  // initial load: meta + counts
  useEffect(() => {
    void loadSessionMeta();
    void loadCounts();
    countsTimerRef.current = setInterval(loadCounts, 5000);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // load/rotate token only when QR is enabled
  useEffect(() => {
    if (!qrEnabled) return;
    void loadToken();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, qrEnabled]);

  const copyToken = async () => {
    try {
      await navigator.clipboard.writeText(token);
      setErr("");
    } catch {
      setErr("Could not copy token");
    }
  };

  const onManualRefresh = () => {
    if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
    void loadToken();
  };

  const onManualSuccess = (attendance) => {
    setOk(`Marked present: student #${attendance?.student?.id ?? ""}`);
    setTimeout(() => setOk(""), 4000);
    void loadCounts();
  };

  const doStopSession = async () => {
    try {
      setStopping(true);
      await stopSession(id);
      navigate("/admin", { replace: true });
    } catch (e) {
      setErr(e.message || "Failed to stop session");
    } finally {
      setStopping(false);
      setConfirmStop(false);
    }
  };

  const pct = total > 0 ? Math.round((present * 100) / total) : 0;
  const secondsLeft = Math.ceil(countdown / 1000);

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={topbar}>
          <h1 style={title}>Active Session</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={btnGhost} onClick={() => navigate("/admin")}>
              ← Dashboard
            </button>
            <button style={btnDanger} onClick={logout}>
              Logout
            </button>
          </div>
        </div>

        <TeacherPasswordBar />

        {err && <p style={errorBox}>{err}</p>}
        {ok && <p style={okBox}>{ok}</p>}

        <div style={layout}>
          {/* LEFT: QR panel (hidden if QR disabled) */}
          <div style={cardLeft}>
            {qrEnabled ? (
              <>
                <canvas
                  ref={canvasRef}
                  style={{
                    width: 320,
                    height: 320,
                    borderRadius: 12,
                    background: "#0b1220",
                  }}
                />
                <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
                  <button style={btnPrimary} onClick={onManualRefresh} disabled={loading}>
                    Refresh QR
                  </button>
                  <button style={btnGhost} onClick={copyToken} disabled={!token}>
                    Copy token
                  </button>
                  <button style={btnAccent} onClick={() => setShowManual(true)}>
                    Manual Mark
                  </button>
                  {!confirmStop ? (
                    <button style={btnWarn} onClick={() => setConfirmStop(true)}>
                      Stop Session
                    </button>
                  ) : (
                    <div style={confirmBox}>
                      <span>Confirm stop?</span>
                      <button style={btnDanger} onClick={doStopSession} disabled={stopping}>
                        {stopping ? "Stopping…" : "Confirm Stop"}
                      </button>
                      <button style={btnGhost} onClick={() => setConfirmStop(false)}>
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <>
                <div
                  style={{
                    width: 320,
                    height: 320,
                    borderRadius: 12,
                    background: "#0b1220",
                    border: "1px dashed #334155",
                    display: "grid",
                    placeItems: "center",
                    color: "#94a3b8",
                    textAlign: "center",
                    padding: 12,
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 800, marginBottom: 6 }}>QR disabled</div>
                    <div style={{ fontSize: 13 }}>
                      This session’s flow does not include a QR step. Students will not be asked
                      for a QR token.
                    </div>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
                  <button style={btnAccent} onClick={() => setShowManual(true)}>
                    Manual Mark
                  </button>
                  {!confirmStop ? (
                    <button style={btnWarn} onClick={() => setConfirmStop(true)}>
                      Stop Session
                    </button>
                  ) : (
                    <div style={confirmBox}>
                      <span>Confirm stop?</span>
                      <button style={btnDanger} onClick={doStopSession} disabled={stopping}>
                        {stopping ? "Stopping…" : "Confirm Stop"}
                      </button>
                      <button style={btnGhost} onClick={() => setConfirmStop(false)}>
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          {/* RIGHT: details / stats */}
          <div style={cardRight}>
            <div style={{ marginBottom: 8 }}>
              <div style={badge}>Session</div>
              <h3 style={h3}>ID: {id}</h3>
              <p style={muted}>
                {qrEnabled
                  ? "QR rotates automatically. Use “Manual Mark” only for exceptions."
                  : "QR is disabled for this session."}
              </p>
            </div>

            {qrEnabled && (
              <>
                <InfoRow
                  label="Last updated"
                  value={lastUpdated ? new Date(lastUpdated).toLocaleTimeString() : "—"}
                />
                <InfoRow
                  label="Next rotation in"
                  value={Number.isFinite(secondsLeft) ? `${secondsLeft}s` : "—"}
                />
                <InfoRow
                  label="Expires at"
                  value={expiresAt ? new Date(expiresAt).toLocaleTimeString() : "—"}
                />
              </>
            )}

            <div style={{ marginTop: 12 }}>
              <div style={lbl}>Attendance (live)</div>
              <div style={kpis}>
                <KPI label="Present" value={present} />
                <KPI label="Total Marks" value={total} />
                <KPI label="%" value={`${pct}%`} />
              </div>

              <div style={progressOuter}>
                <div
                  style={{
                    ...progressInner,
                    width: `${Math.min(100, Math.max(0, pct))}%`,
                  }}
                />
              </div>

              <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <button style={btnGhost} onClick={loadCounts}>
                  Refresh counts
                </button>
              </div>
            </div>

            {qrEnabled && (
              <div style={{ marginTop: 12 }}>
                <div style={lbl}>Raw token (JWT)</div>
                <textarea readOnly value={token} style={textarea} placeholder="Waiting for token…" />
              </div>
            )}
          </div>
        </div>
      </div>

      <ManualMarkDialog
        open={showManual}
        onClose={() => setShowManual(false)}
        sessionId={id}
        onSuccess={onManualSuccess}
      />
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        borderBottom: "1px dashed #243244",
        padding: "6px 0",
      }}
    >
      <div style={{ color: "#94a3b8", fontSize: 13 }}>{label}</div>
      <div style={{ fontWeight: 700 }}>{value}</div>
    </div>
  );
}

function KPI({ label, value }) {
  return (
    <div style={kpiCard}>
      <div style={{ fontSize: 12, color: "#94a3b8" }}>{label}</div>
      <div style={{ fontSize: 22, fontWeight: 800 }}>{value}</div>
    </div>
  );
}

/* styles (unchanged) */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 1100, margin: "0 auto" };
const topbar = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 };
const title = { margin: 0, fontSize: 24, fontWeight: 800 };
const layout = { display: "grid", gridTemplateColumns: "360px 1fr", gap: 12 };
const cardLeft = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 16, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };
const cardRight = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 16, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };
const h3 = { margin: "8px 0 4px", fontSize: 18, fontWeight: 800 };
const muted = { margin: 0, color: "#94a3b8", fontSize: 13 };
const lbl = { display: "block", fontSize: 13, color: "#cbd5e1", marginBottom: 6 };
const textarea = { width: "100%", minHeight: 110, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: 10, fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 12 };
const badge = { display: "inline-block", padding: "2px 8px", fontSize: 12, borderRadius: 999, background: "#1e293b", border: "1px solid #334155", color: "#cbd5e1" };
const kpis = { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginTop: 6 };
const kpiCard = { background: "#0b1220", border: "1px solid #243244", borderRadius: 12, padding: 12 };
const progressOuter = { height: 10, background: "#0b1220", border: "1px solid #243244", borderRadius: 999, overflow: "hidden", marginTop: 6 };
const progressInner = { height: "100%", background: "#2563eb" };
const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const btnDanger = { padding: "10px 14px", border: "1px solid #7f1d1d", background: "#450a0a", color: "#fecaca", cursor: "pointer" };
const btnAccent = { padding: "10px 14px", borderRadius: 10, border: "1px solid #14532d", background: "#052e16", color: "#bbf7d0", cursor: "pointer" };
const btnWarn = { padding: "10px 14px", borderRadius: 10, border: "1px solid #92400e", background: "#3f1d0f", color: "#fde68a", cursor: "pointer" };
const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginBottom: 8, fontSize: 13 };
const okBox = { background: "#0b3b18", border: "1px solid #14532d", color: "#bbf7d0", padding: "8px 10px", borderRadius: 10, marginBottom: 8, fontSize: 13 };
const confirmBox = { display: "inline-flex", gap: 8, alignItems: "center", padding: "6px 8px", borderRadius: 10, border: "1px solid #92400e", background: "#1f2937" };
