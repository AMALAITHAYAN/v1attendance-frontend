import axios from "./axiosInstance";
import { teacherHeadersOrThrow } from "../utils/teacherAuth";
import api from "./axiosInstance";

/** tiny helper used when wifiPolicy requires a public IP */
export async function getPublicIp() {
  try {
    const res = await fetch("https://api.ipify.org?format=json");
    const data = await res.json();
    return data?.ip || "";
  } catch {
    return "";
  }
}

/**
 * Start a session
 * input:
 *   {
 *     year:number, department:string, className:string, subject:string,
 *     startTime: ISO, endTime: ISO,
 *     latitude?:number, longitude?:number, radiusMeters?:number,
 *     flow: ("WIFI"|"GEO"|"FACE"|"QR")[],
 *     wifiPolicy: "NONE"|"PUBLIC_IP"|"BOTH",
 *     qrIntervalSeconds:number,
 *     publicIp?:string   // teacher's public IP (required when wifiPolicy ≠ "NONE")
 *   }
 * returns: Session
 */
export async function startSession(input) {
  const headers = teacherHeadersOrThrow();

  const payload = {
    year: Number(input.year),
    department: input.department?.trim(),
    className: input.className?.trim(),
    subject: input.subject?.trim(),
    startTime: input.startTime, // ISO string
    endTime: input.endTime,     // ISO string
    latitude:
      input.latitude === "" || input.latitude == null ? null : Number(input.latitude),
    longitude:
      input.longitude === "" || input.longitude == null ? null : Number(input.longitude),
    radiusMeters:
      input.radiusMeters === "" || input.radiusMeters == null
        ? null
        : Number(input.radiusMeters),
    flow: Array.isArray(input.flow) ? input.flow : [],
    wifiPolicy: input.wifiPolicy || "NONE",
    qrIntervalSeconds: Number(
      input.qrIntervalSeconds ?? input.qrIntervalSec ?? 30
    ),
    publicIp: input.publicIp ?? null,
  };

  // If wifiPolicy needs a public IP and caller didn't supply it, fetch it now.
  if (
    (payload.wifiPolicy === "PUBLIC_IP" || payload.wifiPolicy === "BOTH") &&
    !payload.publicIp
  ) {
    payload.publicIp = await getPublicIp();
  }
  if (payload.wifiPolicy === "NONE") payload.publicIp = null;

  const res = await axios.post("/api/teacher/sessions/start", payload, { headers });
  return res.data;
}

export async function stopSession(sessionId) {
  const headers = teacherHeadersOrThrow();
  const res = await axios.post(`/api/teacher/sessions/${sessionId}/stop`, null, {
    headers,
  });
  return res.data;
}

export async function fetchSessionSummary(sessionId) {
  const headers = teacherHeadersOrThrow();
  const res = await axios.get(`/api/teacher/sessions/${sessionId}/summary`, {
    headers,
  });
  return res.data; // { sessionId, present, total }
}

export async function fetchSessionById(id) {
  const { data } = await api.get(`/api/teacher/sessions/${id}`);
  return data; // should include { id, flow: ["WIFI","GEO","FACE","QR"], ... }
}