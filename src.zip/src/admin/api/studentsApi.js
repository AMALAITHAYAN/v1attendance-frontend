import axios from "./axiosInstance";
import { teacherHeadersOrThrow } from "../utils/teacherAuth";

/** Create a single student (multipart: JSON 'data' + optional 'photo') */
export async function createStudent(form, photoFile) {
  const headers = teacherHeadersOrThrow();

  const payload = {
    username: form.username?.trim(),
    name: form.name?.trim(),
    rollNo: form.rollNo?.trim(),
    className: form.className?.trim(),
    year: form.year?.trim(),
    department: form.department?.trim(),
    password: form.password || "1234",
  };

  const fd = new FormData();
  fd.append("data", new Blob([JSON.stringify(payload)], { type: "application/json" }));
  if (photoFile) fd.append("photo", photoFile);

  const res = await axios.post("/api/teacher/students", fd, { headers });
  return res.data;
}

/** Bulk upload .xlsx */
export async function bulkUploadStudents(file) {
  if (!file) throw new Error("Choose a .xlsx file");
  const headers = teacherHeadersOrThrow();

  const fd = new FormData();
  fd.append("file", file);

  const res = await axios.post("/api/teacher/students/bulk-upload", fd, { headers });
  return res.data;
}

/** Download the CSV template */
export async function downloadTemplate() {
  const res = await axios.get("/api/teacher/students/template", {
    responseType: "blob",
  });
  // Save file
  const url = URL.createObjectURL(res.data);
  const a = document.createElement("a");
  a.href = url;
  a.download = "students_template.csv";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
