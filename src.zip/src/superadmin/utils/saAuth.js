// Everything scoped to superadmin
const USER_KEY = "attendance:user";
const PW_KEY = "attendance:sa:pw"; // stored in sessionStorage, cleared on tab close

export function getAdminUser() {
  try {
    const u = JSON.parse(localStorage.getItem(USER_KEY));
    if (!u || (u.role || "").toUpperCase() !== "SUPER_ADMIN") return null;
    return u; // { username, role, ... }
  } catch { return null; }
}

export function getAdminPassword() {
  return sessionStorage.getItem(PW_KEY) || "";
}

export function setAdminPassword(pw) {
  if (pw) sessionStorage.setItem(PW_KEY, pw);
  else sessionStorage.removeItem(PW_KEY);
}

export function ensureSuperAdminOrThrow() {
  const u = getAdminUser();
  if (!u) throw new Error("Not authenticated as SUPER_ADMIN");
  return u;
}

export function saHeadersOrThrow() {
  const u = ensureSuperAdminOrThrow();
  const pw = getAdminPassword();
  if (!pw) throw new Error("Enter admin password to continue");
  return {
    "X-Auth-Username": u.username,
    "X-Auth-Password": pw,
  };
}
