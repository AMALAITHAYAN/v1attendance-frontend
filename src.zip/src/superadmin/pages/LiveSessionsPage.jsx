import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { createLiveClient } from "../api/liveSseClient";
import { getAdminPassword, setAdminPassword, getAdminUser } from "../utils/saAuth";
import AdminPasswordBar from "./AdminPasswordBar";

export default function LiveSessionsPage() {
  const navigate = useNavigate();
  const admin = getAdminUser();

  useEffect(() => {
    if (!admin) navigate("/login", { replace: true });
  }, [admin, navigate]);

  const [status, setStatus] = useState("disconnected"); // disconnected | connecting | connected | reconnecting
  const [attempts, setAttempts] = useState(0);
  const [err, setErr] = useState("");
  const [events, setEvents] = useState([]); // newest first
  const pw = getAdminPassword();
  const clientRef = useRef(null);
  const listRef = useRef(null);

  const canConnect = useMemo(() => !!(admin?.username && pw), [admin, pw]);

  // Auto-connect when we have a password and are not connected yet.
  useEffect(() => {
    if (canConnect && status === "disconnected") {
      handleConnect();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canConnect]);

  function handleConnect() {
    if (!canConnect) { setErr("Enter admin password to connect."); return; }
    setErr("");
    setStatus(attempts === 0 ? "connecting" : "reconnecting");

    const c = createLiveClient({
      adminUsername: admin.username,
      adminPassword: pw,
      onOpen: ({ attempts: a }) => {
        setAttempts(a);
        setStatus("connected");
      },
      onMessage: ({ id, event, data, raw }) => {
        // Expect data like {"message":"Teacher ... started ..."}
        const msg = typeof data === "object" && data?.message ? data.message : raw;
        const item = {
          id: id || `${Date.now()}`,
          type: event || "message",
          message: msg,
          time: new Date().toLocaleString(),
        };
        setEvents((prev) => [item, ...prev].slice(0, 500)); // cap to 500
      },
      onError: (e) => {
        setErr((e && e.message) || "Stream error");
      },
      onClose: () => {
        if (status !== "disconnected") {
          setStatus("reconnecting");
        }
      },
    });

    clientRef.current = c;
    c.connect();
  }

  function handleDisconnect() {
    clientRef.current?.close();
    clientRef.current = null;
    setStatus("disconnected");
  }

  function handleSnapshot() {
    const snap = {
      takenAt: new Date().toISOString(),
      count: events.length,
      events: events.slice().reverse(), // chronological
    };
    const blob = new Blob([JSON.stringify(snap, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `live-sessions-snapshot-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Live Sessions</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={btnGhost} onClick={() => navigate("/superadmin")}>← Dashboard</button>
          </div>
        </div>

        <AdminPasswordBar />

        <div style={bar}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <StatusDot status={status} />
            <div style={{ fontWeight: 700, fontSize: 14, textTransform: "capitalize" }}>{status}</div>
            {attempts > 0 && <span style={{ fontSize: 12, color: "#94a3b8" }}>retry #{attempts}</span>}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {status === "connected" ? (
              <button style={btnGhost} onClick={handleDisconnect}>Disconnect</button>
            ) : (
              <button style={btnPrimary} onClick={handleConnect} disabled={!canConnect}>
                {attempts === 0 ? "Connect" : "Reconnect"}
              </button>
            )}
            <button style={btnGhost} onClick={() => setEvents([])}>Clear</button>
            <button style={btnPrimary} onClick={handleSnapshot} disabled={events.length === 0}>Snapshot now</button>
          </div>
        </div>

        {err && <p style={errorBox}>{err}</p>}

        <div style={card} ref={listRef}>
          {events.length === 0 ? (
            <div style={{ padding: 16, color: "#94a3b8" }}>
              {status === "connected" ? "Waiting for events…" : "Not connected"}
            </div>
          ) : (
            <ul style={ul}>
              {events.map((e) => (
                <li key={e.id} style={li}>
                  <span style={pill(e.type)}>{labelFor(e.type)}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14 }}>{e.message}</div>
                    <div style={{ fontSize: 12, color: "#94a3b8" }}>{e.time}</div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div style={{ marginTop: 8, fontSize: 12, color: "#94a3b8" }}>
          Note: stream reconnects automatically with backoff. “Snapshot now” downloads the current buffer as JSON.
        </div>
      </div>
    </div>
  );
}

/* small UI bits */
function StatusDot({ status }) {
  const color =
    status === "connected" ? "#22c55e" :
    status === "connecting" ? "#eab308" :
    status === "reconnecting" ? "#f97316" :
    "#ef4444";
  return <span style={{ width: 10, height: 10, background: color, borderRadius: 999, display: "inline-block" }} />;
}
function labelFor(type) {
  if (type === "session-started") return "Started";
  if (type === "session-stopped") return "Stopped";
  return type || "Message";
}

/* styles */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 900, margin: "0 auto" };
const head = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 };
const title = { margin: 0, fontSize: 24, fontWeight: 800 };
const bar = { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, background: "#0b1220", border: "1px solid #243244", padding: 10, borderRadius: 12, marginBottom: 10 };
const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 18px rgba(37,99,235,.35)" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginTop: 6, fontSize: 13 };
const card = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 0, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };
const ul = { listStyle: "none", margin: 0, padding: 0, maxHeight: "60vh", overflow: "auto" };
const li = { display: "flex", alignItems: "flex-start", gap: 10, padding: "12px", borderBottom: "1px solid #1e293b" };
const pill = (type) => ({
  display: "inline-block",
  minWidth: 76,
  textAlign: "center",
  fontSize: 12,
  fontWeight: 800,
  padding: "6px 10px",
  borderRadius: 999,
  background: type === "session-started" ? "#052e16" :
             type === "session-stopped" ? "#3f1d1d" : "#1e293b",
  color: type === "session-started" ? "#86efac" :
         type === "session-stopped" ? "#fecaca" : "#cbd5e1",
});
