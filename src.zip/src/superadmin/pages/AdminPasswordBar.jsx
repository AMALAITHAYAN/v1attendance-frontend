import { getAdminPassword, setAdminPassword, getAdminUser } from "../utils/saAuth";

export default function AdminPasswordBar() {
  const admin = getAdminUser();
  const pw = getAdminPassword();

  return (
    <div style={bar}>
      <div>
        <div style={{ fontSize: 12, color: "#94a3b8" }}>Signed in as</div>
        <div style={{ fontSize: 14, fontWeight: 700 }}>{admin?.username || "—"}</div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <input
          type="password"
          placeholder="Admin password for actions"
          defaultValue={pw}
          onChange={(e) => setAdminPassword(e.target.value)}
          style={pwInput}
        />
      </div>
    </div>
  );
}

const bar = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: 12,
  background: "#0b1220",
  border: "1px solid #243244",
  padding: 10,
  borderRadius: 12,
  marginBottom: 10,
};
const pwInput = { height: 36, width: 280, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 8, padding: "6px 10px" };
