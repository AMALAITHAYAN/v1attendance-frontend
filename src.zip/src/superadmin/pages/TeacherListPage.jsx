import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { listTeachers, deleteTeacher } from "../api/adminApi";
import { getAdminUser } from "../utils/saAuth";
import AdminPasswordBar from "./AdminPasswordBar";

export default function TeacherListPage() {
  const navigate = useNavigate();
  const user = getAdminUser();
  useEffect(() => { if (!user) navigate("/login", { replace: true }); }, [user, navigate]);

  const [q, setQ] = useState("");
  const [page, setPage] = useState(0);
  const [size] = useState(10);
  const [data, setData] = useState({ content: [], totalPages: 0, number: 0 });
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");

  const load = async (p = page, query = q) => {
    try {
      setLoading(true);
      const res = await listTeachers({ page: p, size, q: query });
      setData(res);
      setPage(res.number || 0);
    } catch (e) {
      setErr(e.message || "Failed to load");
    } finally { setLoading(false); }
  };

  useEffect(() => { load(0, ""); /* initial */ }, []);

  const onDelete = async (id) => {
    if (!window.confirm("Delete this teacher?")) return;
    try {
      await deleteTeacher(id);
      setInfo("Teacher deleted");
      load(page, q);
      setTimeout(() => setInfo(""), 2500);
    } catch (e) {
      setErr(e.message || "Delete failed");
    }
  };

  return (
    <div style={pageWrap}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Teachers</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={btnGhost} onClick={() => navigate("/superadmin")}>← Dashboard</button>
            <button style={btnPrimary} onClick={() => navigate("/superadmin/teachers/new")}>+ Create Teacher</button>
          </div>
        </div>

        <AdminPasswordBar />

        <div style={toolbar}>
          <input
            placeholder="Search name or email"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            style={search}
            onKeyDown={(e) => e.key === "Enter" && load(0, q)}
          />
          <button style={btnGhost} onClick={() => load(0, q)} disabled={loading}>Search</button>
        </div>

        {err && <p style={errorBox}>{err}</p>}
        {info && <p style={okBox}>{info}</p>}

        <div style={card}>
          <table style={table}>
            <thead>
              <tr>
                <th style={th}>Name</th>
                <th style={th}>Gmail</th>
                <th style={th}>Subjects</th>
                <th style={{ ...th, width: 160 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.content?.length ? data.content.map((t) => (
                <tr key={t.id}>
                  <td style={td}>{t.name}</td>
                  <td style={td}>{t.gmailId}</td>
                  <td style={td}>{Array.isArray(t.subjects) ? t.subjects.join(", ") : ""}</td>
                  <td style={td}>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button style={btnSmall} onClick={() => navigate(`/superadmin/teachers/${t.id}`)}>Edit</button>
                      <button style={btnSmallDanger} onClick={() => onDelete(t.id)}>Delete</button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr><td style={td} colSpan={4}>{loading ? "Loading…" : "No data"}</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <div style={pager}>
          <button style={btnGhost} disabled={page <= 0} onClick={() => load(page - 1, q)}>Prev</button>
          <span>Page {page + 1} / {Math.max(1, data.totalPages || 1)}</span>
          <button style={btnGhost} disabled={page + 1 >= (data.totalPages || 1)} onClick={() => load(page + 1, q)}>Next</button>
        </div>
      </div>
    </div>
  );
}

/* styles */
const pageWrap = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 1100, margin: "0 auto" };
const head = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 };
const title = { margin: 0, fontSize: 24, fontWeight: 800 };
const toolbar = { display: "flex", gap: 8, marginBottom: 10 };
const search = { height: 40, flex: 1, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: "0 10px" };
const card = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 0, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };
const table = { width: "100%", borderCollapse: "collapse" };
const th = { textAlign: "left", fontWeight: 700, fontSize: 13, color: "#cbd5e1", padding: "12px 12px", borderBottom: "1px solid #243244" };
const td = { padding: "12px 12px", borderBottom: "1px solid #1e293b", fontSize: 14 };
const pager = { display: "flex", justifyContent: "center", alignItems: "center", gap: 10, marginTop: 12 };
const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 18px rgba(37,99,235,.35)" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const btnSmall = { padding: "6px 10px", borderRadius: 8, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer", fontSize: 12 };
const btnSmallDanger = { ...btnSmall, border: "1px solid #7f1d1d", color: "#fecaca", background: "#450a0a" };
const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginTop: 6, fontSize: 13 };
const okBox = { background: "#0b3b18", border: "1px solid #14532d", color: "#bbf7d0", padding: "8px 10px", borderRadius: 10, marginTop: 6, fontSize: 13 };
