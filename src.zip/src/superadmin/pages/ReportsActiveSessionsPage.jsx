import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchActiveSessions } from "../api/reportApi";
import { getAdminUser } from "../utils/saAuth";
import AdminPasswordBar from "./AdminPasswordBar";

export default function ReportsActiveSessionsPage() {
  const navigate = useNavigate();
  const user = getAdminUser();
  useEffect(() => { if (!user) navigate("/login", { replace: true }); }, [user, navigate]);

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");

  const load = async () => {
    try {
      setErr(""); setInfo("");
      setLoading(true);
      const data = await fetchActiveSessions();
      setRows(Array.isArray(data) ? data : []);
      setInfo(`Loaded ${Array.isArray(data) ? data.length : 0} active session(s)`);
    } catch (e) {
      setErr(e.message || "Failed to load");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const exportCSV = () => {
    const header = ["ID","Subject","Class","StartTime","EndTime","TeacherName"];
    const body = rows.map(r => [
      r.id, r.subject, r.className,
      r.startTime, r.endTime ?? "", r.teacherName
    ]);
    const csv = [header, ...body].map(a => a.map(v => `"${String(v ?? "").replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = `active-sessions-${Date.now()}.csv`; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Active Sessions</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={btnGhost} onClick={() => navigate("/superadmin")}>← Dashboard</button>
            <button style={btnGhost} onClick={exportCSV} disabled={!rows.length}>Export CSV</button>
            <button style={btnPrimary} onClick={load} disabled={loading}>{loading ? "Refreshing…" : "Refresh"}</button>
          </div>
        </div>

        <AdminPasswordBar />

        {err && <p style={errorBox}>{err}</p>}
        {info && <p style={okBox}>{info}</p>}

        <div style={card}>
          <table style={table}>
            <thead>
              <tr>
                <th style={th}>Subject</th>
                <th style={th}>Class</th>
                <th style={th}>Teacher</th>
                <th style={th}>Start</th>
                <th style={th}>End</th>
              </tr>
            </thead>
            <tbody>
              {rows.length ? rows.map(s => (
                <tr key={s.id}>
                  <td style={td}>{s.subject}</td>
                  <td style={td}>{s.className}</td>
                  <td style={td}>{s.teacherName}</td>
                  <td style={td}>{fmtDT(s.startTime)}</td>
                  <td style={td}>{s.endTime ? fmtDT(s.endTime) : "—"}</td>
                </tr>
              )) : (
                <tr><td style={td} colSpan={5}>{loading ? "Loading…" : "No active sessions"}</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function fmtDT(s) {
  if (!s) return "";
  // backend sends ISO LocalDateTime; best-effort display
  const t = s.replace(" ", "T");
  return t.length <= 16 ? t : t.slice(0,16); // "YYYY-MM-DDTHH:mm"
}

/* styles */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 1100, margin: "0 auto" };
const head = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 };
const title = { margin: 0, fontSize: 24, fontWeight: 800 };
const card = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 0, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };
const table = { width: "100%", borderCollapse: "collapse" };
const th = { textAlign: "left", fontWeight: 700, fontSize: 13, color: "#cbd5e1", padding: "12px 12px", borderBottom: "1px solid #243244" };
const td = { padding: "12px 12px", borderBottom: "1px solid #1e293b", fontSize: 14 };
const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 18px rgba(37,99,235,.35)" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginTop: 6, fontSize: 13 };
const okBox = { background: "#0b3b18", border: "1px solid #14532d", color: "#bbf7d0", padding: "8px 10px", borderRadius: 10, marginTop: 6, fontSize: 13 };
