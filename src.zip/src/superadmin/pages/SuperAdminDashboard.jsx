import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAdminUser, setAdminPassword } from "../utils/saAuth";

export default function SuperAdminDashboard() {
  const navigate = useNavigate();
  const user = getAdminUser();
  const [studentId, setStudentId] = useState("");

  useEffect(() => {
    if (!user) navigate("/login", { replace: true });
  }, [user, navigate]);

  const goToStudentSummary = () => {
    const id = studentId.trim();
    if (id) navigate(`/superadmin/reports/students/${id}`);
  };

  const onLogout = () => {
    // clear stored auth (username/role + SA password used for admin headers)
    try {
      localStorage.removeItem("attendance:user");
      setAdminPassword(""); // removes attendance:sa:pw from sessionStorage
    } finally {
      navigate("/login", { replace: true });
    }
  };

  return (
    <div style={page}>
      <div style={wrap}>
        {/* Top bar with username + logout */}
        <div style={topbar}>
          <h1 style={title}>Super Admin</h1>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <div style={signedInAs}>
              <span style={{ opacity: 0.75, marginRight: 6 }}>Signed in as</span>
              <strong>{user?.username}</strong>
            </div>
            <button style={btnDanger} onClick={onLogout}>Logout</button>
          </div>
        </div>

        {/* Phase 2 — Teacher Management */}
        <div style={card}>
          <div style={{ marginBottom: 10 }}>
            <div style={badge}>Phase 2</div>
            <h3 style={cardH3}>Teacher Management</h3>
            <p style={muted}>Add / edit / remove teachers.</p>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button style={btnPrimary} onClick={() => navigate("/superadmin/teachers")}>
              Open Teachers
            </button>
            <button style={btnGhost} onClick={() => navigate("/superadmin/teachers/new")}>
              + Create Teacher
            </button>
          </div>
        </div>

        {/* Phase 3 — Live Sessions */}
        <div style={card}>
          <div style={{ marginBottom: 10 }}>
            <div style={badge}>Phase 3</div>
            <h3 style={cardH3}>Live Sessions</h3>
            <p style={muted}>View real-time session start/stop events.</p>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button style={btnGhost} onClick={() => navigate("/superadmin/live")}>
              Open Live Stream
            </button>
          </div>
        </div>

        {/* Phase 4 — Reports */}
        <div style={card}>
          <div style={{ marginBottom: 10 }}>
            <div style={badge}>Phase 4</div>
            <h3 style={cardH3}>Reports</h3>
            <p style={muted}>Active sessions snapshot & student summaries.</p>
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <button style={btnGhost} onClick={() => navigate("/superadmin/reports/active")}>
              Active Sessions Report
            </button>

            {/* Inline student summary control (no popup) */}
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <input
                inputMode="numeric"
                placeholder="Student ID"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value.replace(/\D/g, ""))}
                style={inputSmall}
              />
              <button
                style={btnPrimary}
                onClick={goToStudentSummary}
                disabled={!studentId}
                title={studentId ? "Open summary" : "Enter a student ID"}
              >
                Student Summary
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* styles */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 900, margin: "0 auto" };
const topbar = { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 };
const title = { margin: "4px 0 8px", fontSize: 26, fontWeight: 800 };
const signedInAs = { fontSize: 13, color: "#cbd5e1" };

const card = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 16, boxShadow: "0 10px 22px rgba(0,0,0,.35)", maxWidth: 560, marginBottom: 14 };
const badge = { display: "inline-block", padding: "2px 8px", fontSize: 12, borderRadius: 999, background: "#1e293b", border: "1px solid #334155", color: "#cbd5e1" };
const cardH3 = { margin: "8px 0 6px", fontSize: 18, fontWeight: 800 };
const muted = { margin: 0, color: "#94a3b8", fontSize: 13 };

const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 18px rgba(37,99,235,.35)" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const btnDanger = { padding: "10px 14px", borderRadius: 10, border: "1px solid #7f1d1d", background: "#450a0a", color: "#fecaca", cursor: "pointer" };

const inputSmall = { height: 40, width: 160, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: "0 10px" };
