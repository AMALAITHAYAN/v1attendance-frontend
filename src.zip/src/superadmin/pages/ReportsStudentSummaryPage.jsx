import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { fetchStudentSummary } from "../api/reportApi";
import { getAdminUser } from "../utils/saAuth";
import AdminPasswordBar from "./AdminPasswordBar";

export default function ReportsStudentSummaryPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const user = getAdminUser();
  useEffect(() => { if (!user) navigate("/login", { replace: true }); }, [user, navigate]);

  // Defaults: current month start → now
  const now = useMemo(() => new Date(), []);
  const monthStart = useMemo(() => new Date(now.getFullYear(), now.getMonth(), 1, 0, 0), [now]);

  const [studentId, setStudentId] = useState(id || "");
  const [from, setFrom] = useState(toLocalInputValue(monthStart)); // "YYYY-MM-DDTHH:mm"
  const [to, setTo] = useState(toLocalInputValue(now));
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [summary, setSummary] = useState(null);

  const load = async () => {
    if (!studentId) { setErr("Student ID is required"); return; }
    if (new Date(from) > new Date(to)) { setErr("From must be before To"); return; }
    try {
      setErr(""); setLoading(true);
      const fromISO = toApiISO(from);
      const toISO = toApiISO(to);
      const data = await fetchStudentSummary(studentId, fromISO, toISO);
      setSummary(data);
    } catch (e) {
      setErr(e.message || "Failed to load summary");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { if (id) setStudentId(id); }, [id]);

  const quick = (days) => {
    const end = new Date(); const start = new Date(); start.setDate(end.getDate() - days);
    setFrom(toLocalInputValue(start)); setTo(toLocalInputValue(end));
  };

  const exportCSV = () => {
    if (!summary) return;
    const rows = [
      ["present", summary.present],
      ["total", summary.total],
      ["percentage", summary.percentage],
      [],
      ["Subject","Present","Total","Percentage"],
      ...(summary.bySubject || []).map(s => [s.subject, s.present, s.total, s.percentage]),
    ];
    const csv = rows.map(r => r.map(v => `"${String(v ?? "").replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = `student-${studentId}-summary-${Date.now()}.csv`; a.click(); URL.revokeObjectURL(url);
  };

  const faceRegisterPath = `/superadmin/students/${studentId || id}/face-register`;

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Student Summary</h1>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button style={btnGhost} onClick={() => navigate("/superadmin")}>← Dashboard</button>
            <Link to="/superadmin/reports/active" style={{ ...btnGhost, textDecoration: "none", display: "inline-block" }}>Active Sessions</Link>

            {/* NEW: Quick link to Face Registration for this student */}
            <button
              style={btnGhost}
              onClick={() => navigate(faceRegisterPath)}
              disabled={!(studentId || id)}
              title={studentId || id ? "Open Face Registration" : "Enter a Student ID first"}
            >
              Register Face
            </button>

            <button style={btnGhost} onClick={exportCSV} disabled={!summary}>Export CSV</button>
            <button style={btnPrimary} onClick={load} disabled={loading}>{loading ? "Loading…" : "Load"}</button>
          </div>
        </div>

        <AdminPasswordBar />

        <div style={cardPad}>
          <div style={grid3}>
            <div>
              <label style={lbl}>Student ID *</label>
              <input style={input} value={studentId} onChange={(e) => setStudentId(e.target.value.replace(/\D/g,''))} placeholder="e.g. 101" />
            </div>
            <div>
              <label style={lbl}>From *</label>
              <input type="datetime-local" style={input} value={from} onChange={(e) => setFrom(e.target.value)} />
            </div>
            <div>
              <label style={lbl}>To *</label>
              <input type="datetime-local" style={input} value={to} onChange={(e) => setTo(e.target.value)} />
            </div>
          </div>

          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button style={btnGhost} onClick={() => quick(7)}>Last 7 days</button>
            <button style={btnGhost} onClick={() => quick(30)}>Last 30 days</button>
            <button style={btnGhost} onClick={() => { setFrom(toLocalInputValue(new Date(new Date().getFullYear(), new Date().getMonth(), 1, 0, 0))); setTo(toLocalInputValue(new Date())); }}>
              This month
            </button>
          </div>
        </div>

        {err && <p style={errorBox}>{err}</p>}

        {summary && (
          <>
            <div style={cardsRow}>
              <KPI label="Present" value={summary.present} />
              <KPI label="Total" value={summary.total} />
              <KPI label="Percentage" value={`${summary.percentage}%`} />
            </div>

            <div style={card}>
              <table style={table}>
                <thead>
                  <tr>
                    <th style={th}>Subject</th>
                    <th style={th}>Present</th>
                    <th style={th}>Total</th>
                    <th style={th}>%</th>
                    <th style={th}>Progress</th>
                  </tr>
                </thead>
                <tbody>
                  {(summary.bySubject || []).map((s) => (
                    <tr key={s.subject}>
                      <td style={td}>{s.subject}</td>
                      <td style={td}>{s.present}</td>
                      <td style={td}>{s.total}</td>
                      <td style={td}>{s.percentage}</td>
                      <td style={td}>
                        <div style={barOuter}>
                          <div style={{ ...barInner, width: `${Math.min(100, Math.max(0, s.percentage))}%` }} />
                        </div>
                      </td>
                    </tr>
                  ))}
                  {!summary.bySubject?.length && (
                    <tr><td style={td} colSpan={5}>No data</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* helpers */
function toLocalInputValue(d) {
  const pad = (n) => String(n).padStart(2, "0");
  const y = d.getFullYear(), m = pad(d.getMonth()+1), day = pad(d.getDate());
  const h = pad(d.getHours()), min = pad(d.getMinutes());
  return `${y}-${m}-${day}T${h}:${min}`; // HTML datetime-local format
}
// Convert to ISO_LOCAL_DATE_TIME (no timezone), adding seconds
function toApiISO(localVal) {
  // "YYYY-MM-DDTHH:mm" -> "YYYY-MM-DDTHH:mm:00"
  return localVal.length === 16 ? `${localVal}:00` : localVal;
}

function KPI({ label, value }) {
  return (
    <div style={kpi}>
      <div style={{ fontSize: 12, color: "#94a3b8" }}>{label}</div>
      <div style={{ fontSize: 22, fontWeight: 800 }}>{value}</div>
    </div>
  );
}

/* styles */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 1100, margin: "0 auto" };
const head = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 };
const title = { margin: 0, fontSize: 24, fontWeight: 800 };

const card = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 0, boxShadow: "0 10px 22px rgba(0,0,0,.35)", marginTop: 10 };
const cardPad = { ...card, padding: 12, marginTop: 0 };

const grid3 = { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 };
const lbl = { display: "block", fontSize: 13, color: "#cbd5e1", marginBottom: 6 };
const input = { width: "100%", height: 40, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: "8px 10px" };

const cardsRow = { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginTop: 10 };
const kpi = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 12, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };

const table = { width: "100%", borderCollapse: "collapse" };
const th = { textAlign: "left", fontWeight: 700, fontSize: 13, color: "#cbd5e1", padding: "12px 12px", borderBottom: "1px solid #243244" };
const td = { padding: "12px 12px", borderBottom: "1px solid #1e293b", fontSize: 14 };

const barOuter = { height: 10, background: "#0b1220", border: "1px solid #2b3a55", borderRadius: 999, overflow: "hidden" };
const barInner = { height: "100%", background: "#2563eb" };

const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 18px rgba(37,99,235,.35)" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginTop: 6, fontSize: 13 };
