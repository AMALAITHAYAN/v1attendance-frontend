import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getAdminUser } from "../utils/saAuth";
import { registerFaceForStudent } from "../api/faceApi";
import AdminPasswordBar from "./AdminPasswordBar";

export default function FaceRegisterPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const admin = getAdminUser();

  useEffect(() => { if (!admin) navigate("/login", { replace: true }); }, [admin, navigate]);

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [result, setResult] = useState(null);

  const onRegister = async () => {
    setErr(""); setResult(null);
    try {
      setLoading(true);
      const data = await registerFaceForStudent(id);
      setResult(data);
    } catch (e) {
      setErr(e?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Face Registration</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={btnGhost} onClick={() => navigate(-1)}>← Back</button>
            <button style={btnGhost} onClick={() => navigate("/superadmin")}>Dashboard</button>
          </div>
        </div>

        <AdminPasswordBar />

        <div style={card}>
          <div style={{ padding: 12, borderBottom: "1px solid #1e293b" }}>
            <div style={{ fontSize: 13, color: "#94a3b8" }}>Student ID</div>
            <div style={{ fontWeight: 800, fontSize: 18 }}>{id}</div>
          </div>

          <div style={{ padding: 12, display: "flex", gap: 8, alignItems: "center" }}>
            <button style={btnPrimary} onClick={onRegister} disabled={loading}>
              {loading ? "Registering…" : "Register Face"}
            </button>
            <span style={{ fontSize: 13, color: "#94a3b8" }}>
              Uses stored student photo on the server.
            </span>
          </div>

          {err && <div style={{ ...box, background: "#7f1d1d", borderColor: "#7f1d1d", color: "#fecaca" }}>{err}</div>}

          {result && (
            <div style={{ ...box, background: "#0b3b18", borderColor: "#14532d", color: "#bbf7d0" }}>
              <div style={{ fontWeight: 700, marginBottom: 6 }}>Result</div>
              <pre style={pre}>{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* styles */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 900, margin: "0 auto" };
const head = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 };
const title = { margin: 0, fontSize: 24, fontWeight: 800 };
const card = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 0, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };
const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 18px rgba(37,99,235,.35)" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const box = { margin: 12, marginTop: 0, border: "1px solid", borderRadius: 10, padding: 12 };
const pre = { margin: 0, whiteSpace: "pre-wrap", wordBreak: "break-word", fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace", fontSize: 12 };
