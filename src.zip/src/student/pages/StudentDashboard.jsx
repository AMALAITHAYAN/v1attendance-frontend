// src/student/pages/StudentDashboard.jsx
import { useMemo } from "react";
import { useNavigate, Link } from "react-router-dom";

export default function StudentDashboard() {
  const nav = useNavigate();

  // read once; router guards handle auth redirects
  const username = useMemo(
    () => String(localStorage.getItem("attendance:studentUser") || ""),
    []
  );

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Student</h1>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Link to="/student/mark" style={btnGhost}>Mark Attendance</Link>
            <Link to="/student/reports" style={btnPrimary}>My Reports</Link>
            <Link to="/change-password" style={btnAccent}>Change Password</Link>
            <button
              style={btnDanger}
              onClick={() => {
                localStorage.removeItem("attendance:studentUser");
                localStorage.removeItem("attendance:studentPass");
                nav("/login", { replace: true });
              }}
            >
              Logout
            </button>
          </div>
        </div>

        <div style={card}>
          <p style={{ margin: 0, color: "#94a3b8" }}>
            {username ? <><strong>{username}</strong> — </> : null}
            Use <strong>Mark Attendance</strong> to complete the flow:
            <span> IP &amp; Location → Face → QR</span>. View your summaries and logs in <strong>My Reports</strong>.  
            Manage your credentials with <strong>Change Password</strong>.
          </p>
        </div>
      </div>
    </div>
  );
}

/* styles */
const page  = { minHeight:"100vh", background:"linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color:"#e2e8f0", padding:24 };
const wrap  = { maxWidth:900, margin:"0 auto" };
const head  = { display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 };
const title = { margin:0, fontSize:24, fontWeight:800 };
const card  = { background:"#111827", border:"1px solid #243244", borderRadius:14, padding:14, boxShadow:"0 10px 22px rgba(0,0,0,.35)" };

const btnGhost   = { padding:"10px 14px", borderRadius:10, border:"1px solid #334155", background:"#0b1220", color:"#cbd5e1", cursor:"pointer", textDecoration:"none" };
const btnPrimary = { padding:"10px 14px", borderRadius:10, border:"none", background:"#2563eb", color:"#ffffff", fontWeight:800, cursor:"pointer", textDecoration:"none" };
const btnAccent  = { padding:"10px 14px", borderRadius:10, border:"1px solid #14532d", background:"#052e16", color:"#bbf7d0", cursor:"pointer", textDecoration:"none" };
const btnDanger  = { padding:"10px 14px", borderRadius:10, border:"1px solid #7f1d1d", background:"#450a0a", color:"#fecaca", cursor:"pointer" };
