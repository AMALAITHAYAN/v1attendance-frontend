// src/student/pages/MarkAttendancePage.jsx
import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { getStudentUser, setStudentPass } from "../utils/studentAuth";
import StudentPasswordBar from "./StudentPasswordBar";

import { getPublicIp } from "../api/publicIp";
import { getStudentSessionMeta } from "../api/studentSessionApi";

import {
  checkWifiApi,
  checkGeoApi,
  checkFaceApi,
  checkQrApi,
} from "../api/checksApi";
import { markAttendanceApi } from "../api/attendanceApi";

/* ---------- tiny hooks ---------- */
function usePublicIpAuto() {
  const [ip, setIp] = useState("");
  useEffect(() => { getPublicIp().then(setIp).catch(()=>{}); }, []);
  const refresh = async () => { try { setIp(await getPublicIp()); } catch {} };
  return { ip, refresh };
}

function useCurrentLocation() {
  const [coords, setCoords] = useState({ lat: "", lng: "" });
  const [msg, setMsg] = useState("");
  const run = useCallback(() => {
    if (!navigator.geolocation) { setMsg("Geolocation not supported"); return; }
    setMsg("Fetching location…");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setMsg(`Location set (±${Math.round(pos.coords.accuracy)}m)`);
      },
      (err) => setMsg(`Location error: ${err.message}`),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }, []);
  return { ...coords, msg, run };
}

/* ---------- step helpers ---------- */
const STEP = { PICK_SESSION: 0, WIFI_GEO: 1, FACE: 2, QR: 3, DONE: 4 };

function collapseFlowToSteps(flow) {
  const hasWifi = flow.includes("WIFI");
  const hasGeo  = flow.includes("GEO");
  const hasFace = flow.includes("FACE");
  const hasQr   = flow.includes("QR");
  const steps = [];
  if (hasWifi || hasGeo) steps.push(STEP.WIFI_GEO);
  if (hasFace) steps.push(STEP.FACE);
  if (hasQr)   steps.push(STEP.QR);
  return steps;
}
function nextStepFrom(current, orderedSteps) {
  const i = orderedSteps.indexOf(current);
  if (i === -1) return orderedSteps[0] ?? STEP.DONE;
  return orderedSteps[i + 1] ?? STEP.DONE;
}

/* ---------- page ---------- */
export default function MarkAttendancePage() {
  const nav = useNavigate();
  const user = getStudentUser();
  useEffect(() => { if (!user) nav("/login", { replace: true }); }, [user, nav]);

  const [step, setStep] = useState(STEP.PICK_SESSION);

  // session / flow
  const [sessionId, setSessionId] = useState("");
  const [flow, setFlow] = useState([]); // ["WIFI","GEO","FACE","QR"]
  const orderedSteps = useMemo(() => collapseFlowToSteps(flow), [flow]);

  // inputs
  const { ip, refresh: refreshIp } = usePublicIpAuto();
  const { lat, lng, msg: geoMsg, run: getLoc } = useCurrentLocation();

  // face capture
  const [selfieFile, setSelfieFile] = useState(null);
  const [selfiePreview, setSelfiePreview] = useState("");
  const [camOn, setCamOn] = useState(false);
  const [camMsg, setCamMsg] = useState("");
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  // qr
  const [qrToken, setQrToken] = useState("");
  const [scanErr, setScanErr] = useState("");
  const [scanning, setScanning] = useState(false);
  const qrVideoRef = useRef(null);
  const qrStreamRef = useRef(null);
  const rafRef = useRef(null);

  // ui
  const [ok, setOk] = useState("");
  const [err, setErr] = useState("");
  const [checks, setChecks] = useState(null);
  const [loading, setLoading] = useState(false);

  // autostart geo
  useEffect(() => { getLoc(); }, [getLoc]);

  const needsWifi = flow.includes("WIFI");
  const needsGeo  = flow.includes("GEO");
  const needsFace = flow.includes("FACE");
  const needsQr   = flow.includes("QR");

  const canContinueWifi = useMemo(() => {
    const wifiInputs = !needsWifi || Boolean(ip);
    const geoInputs  = !needsGeo  || (lat !== "" && lng !== "");
    return Boolean(sessionId && wifiInputs && geoInputs);
  }, [sessionId, ip, lat, lng, needsWifi, needsGeo]);

  /* ---------- load session meta ---------- */
  const loadMeta = async () => {
    setErr(""); setOk(""); setChecks(null); setFlow([]);
    if (!sessionId) { setErr("Enter a session ID"); return; }
    try {
      const meta = await getStudentSessionMeta(Number(sessionId));
      const f = Array.isArray(meta?.flow) ? meta.flow : [];
      if (!f.length) {
        setErr("This session has no validation flow configured.");
        return;
      }
      setFlow(f);
      const first = collapseFlowToSteps(f)[0];
      setStep(first ?? STEP.DONE);
    } catch (e) {
      if (e.code === "SESSION_NOT_FOUND") {
        setErr("Session not found");
      } else if (e.code === "SESSION_EXPIRED") {
        setErr("Session overed");
      } else {
        setErr(e?.message || "Could not load session");
      }
    }
  };

  /* ---------- camera helpers ---------- */
  const stopCamera = useCallback(() => {
    const s = streamRef.current;
    if (s) { s.getTracks().forEach(t => t.stop()); streamRef.current = null; }
    const v = videoRef.current;
    if (v) { try { v.pause(); } catch {} v.srcObject = null; }
    setCamOn(false);
    setCamMsg("");
  }, []);
  const stopQr = useCallback(() => {
    setScanning(false);
    if (rafRef.current) { cancelAnimationFrame(rafRef.current); rafRef.current = null; }
    const s = qrStreamRef.current;
    if (s) { s.getTracks().forEach(t => t.stop()); qrStreamRef.current = null; }
    const v = qrVideoRef.current;
    if (v) { try { v.pause(); } catch {} v.srcObject = null; }
  }, []);
  useEffect(() => () => { stopCamera(); stopQr(); }, [stopCamera, stopQr]);

  const startCamera = async () => {
    setErr(""); setScanErr(""); setCamMsg("");
    stopQr();
    if (camOn && videoRef.current?.srcObject) return;
    try {
      setCamOn(true);
      await new Promise(requestAnimationFrame);
      const video = videoRef.current;
      if (!video) { setErr("Camera view unavailable"); setCamOn(false); return; }
      video.setAttribute("playsinline", "");
      video.setAttribute("autoplay", "");
      video.muted = true;

      setCamMsg("Requesting camera…");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      });
      streamRef.current = stream;
      video.srcObject = stream;

      await new Promise((res) => {
        if (video.readyState >= 1) return res();
        const onMeta = () => { video.removeEventListener("loadedmetadata", onMeta); res(); };
        video.addEventListener("loadedmetadata", onMeta);
      });
      await new Promise((res) => {
        if (video.readyState >= 3) return res();
        const onCanPlay = () => { video.removeEventListener("canplay", onCanPlay); res(); };
        video.addEventListener("canplay", onCanPlay);
      });
      try { await video.play(); } catch {}
      const track = stream.getVideoTracks?.[0];
      setCamMsg(`Camera ready • ${track?.label || "camera"}`);
    } catch (e) {
      setErr("Could not access camera: " + (e?.message || e));
      stopCamera();
    }
  };

  const captureSelfie = async () => {
    const video = videoRef.current;
    if (!video) return;
    if (!video.videoWidth) {
      await new Promise(r => {
        const h = () => { video.removeEventListener("loadedmetadata", h); r(); };
        video.addEventListener("loadedmetadata", h);
      });
    }
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise(res => canvas.toBlob(res, "image/jpeg", 0.9));
    const file = new File([blob], "selfie.jpg", { type: "image/jpeg" });
    setSelfieFile(file);
    const url = URL.createObjectURL(blob);
    setSelfiePreview((old) => { if (old) URL.revokeObjectURL(old); return url; });
    stopCamera();
  };

  /* ---------- QR scan ---------- */
  const startQrScan = async () => {
    setScanErr("");
    stopCamera();
    if (!("BarcodeDetector" in window)) {
      setScanErr("Scanner not supported in this browser. Paste token manually.");
      return;
    }
    try {
      const det = new window.BarcodeDetector({ formats: ["qr_code"] });
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }, audio: false
      });
      qrStreamRef.current = stream;
      const v = qrVideoRef.current;
      if (v) {
        v.setAttribute("playsinline", "");
        v.setAttribute("autoplay", "");
        v.muted = true;
        v.srcObject = stream;
        await new Promise((res) => {
          if (v.readyState >= 1) return res();
          const onMeta = () => { v.removeEventListener("loadedmetadata", onMeta); res(); };
          v.addEventListener("loadedmetadata", onMeta);
        });
        try { await v.play(); } catch {}
      }
      setScanning(true);
      const tick = async () => {
        if (!qrVideoRef.current) return;
        try {
          const codes = await det.detect(qrVideoRef.current);
          if (codes?.length) {
            setQrToken(codes[0].rawValue || "");
            stopQr();
            return;
          }
        } catch {}
        rafRef.current = requestAnimationFrame(tick);
      };
      rafRef.current = requestAnimationFrame(tick);
    } catch {
      setScanErr("Could not start camera for scanning.");
    }
  };

  /* ---------- commit ---------- */
  const commit = async () => {
    const payload = {
      sessionId: Number(sessionId),
      publicIp: ip || "",
      studentLat: lat === "" ? null : Number(lat),
      studentLng: lng === "" ? null : Number(lng),
      qrToken: qrToken || null,
    };
    try {
      setLoading(true);
      const r = await markAttendanceApi(payload, needsFace ? (selfieFile || null) : null);
      setOk("Attendance marked.");
      setChecks(r?.data?.checks || null);
      setStep(STEP.DONE);
    } catch (e) {
      const status = e?.response?.status || e?.status;
      const data   = e?.response?.data   || e?.data;
      if (status === 409 && data) {
        setErr(data.message || "Check failed");
        setChecks(data.checks || null);
      } else {
        setErr(e.message || "Submit failed");
      }
    } finally {
      setLoading(false);
    }
  };

  const advanceOrCommit = (passedStep) => {
    const next = nextStepFrom(passedStep, orderedSteps);
    if (next === STEP.DONE) commit();
    else setStep(next);
  };

  /* ---------- step handlers ---------- */
  const runWifiGeoChecks = async () => {
    setErr(""); setOk(""); setChecks(null);
    const newChecks = {};
    let wifiOk = true, geoOk = true;

    try {
      setLoading(true);

      if (needsWifi) {
        const w = await checkWifiApi({ sessionId: Number(sessionId), studentPublicIp: ip || "" });
        if (w.ok) newChecks.WIFI = { ok: true, ...(w.data || {}) };
        else { newChecks.WIFI = { ok: false, ...(w.error || {}) }; wifiOk = false; }
      }
      if (needsGeo) {
        const g = await checkGeoApi({ sessionId: Number(sessionId), studentLat: Number(lat), studentLng: Number(lng) });
        if (g.ok) newChecks.GEO = { ok: true, ...(g.data || {}) };
        else { newChecks.GEO = { ok: false, ...(g.error || {}) }; geoOk = false; }
      }

      setChecks(newChecks);

      if ((needsWifi ? wifiOk : true) && (needsGeo ? geoOk : true)) {
        setOk("Wi-Fi/Geo verified.");
        advanceOrCommit(STEP.WIFI_GEO);
      } else {
        setErr("Fix the highlighted checks and try again.");
      }
    } catch (e) {
      setErr(e.message || "Check failed");
    } finally {
      setLoading(false);
    }
  };

  const runFaceCheck = async () => {
    setErr(""); setOk(""); setChecks(null);
    try {
      setLoading(true);
      const r = await checkFaceApi(Number(sessionId), selfieFile);
      if (r.ok) {
        setChecks({ FACE: { ok: true, ...(r.data || {}) } });
        setOk("Face verified.");
        advanceOrCommit(STEP.FACE);
      } else {
        setChecks({ FACE: { ok: false, ...(r.error || {}) } });
        setErr("Face not match.");
      }
    } catch (e) {
      setErr(e.message || "Face check failed");
    } finally {
      setLoading(false);
    }
  };

  const runQrCheckThenCommit = async () => {
    setErr(""); setOk(""); setChecks(null);
    try {
      setLoading(true);
      const r = await checkQrApi({ sessionId: Number(sessionId), qrToken: qrToken || "" });
      if (r.ok) {
        setChecks({ QR: { ok: true, ...(r.data || {}) } });
        setOk("QR verified.");
        // last step → commit
        await commit();
      } else {
        setChecks({ QR: { ok: false, ...(r.error || {}) } });
        setErr("QR invalid or expired.");
      }
    } catch (e) {
      setErr(e.message || "QR check failed");
    } finally {
      setLoading(false);
    }
  };

  /* ---------- UI ---------- */
  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Mark Attendance</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={btnGhost} onClick={() => nav("/student")}>← Dashboard</button>
            <button
              style={btnDanger}
              onClick={() => { localStorage.removeItem("attendance:studentUser"); setStudentPass(null); nav("/login", { replace: true }); }}
            >
              Logout
            </button>
          </div>
        </div>

        <StudentPasswordBar />

        {/* Flow chips */}
        {flow.length > 0 && (
          <div style={{ display:"flex", gap:10, marginBottom:10, flexWrap:"wrap" }}>
            {flow.map((x, i) => (
              <span key={i} style={{ padding:"6px 10px", borderRadius:999, border:"1px solid #334155", color:"#cbd5e1" }}>{x}</span>
            ))}
          </div>
        )}

        {err && <p style={errorBox}>{err}</p>}
        {checks && <ChecksBreakdown checks={checks} />}
        {ok && <p style={okBox}>{ok}</p>}

        {/* STEP 0: session id */}
        {step === STEP.PICK_SESSION && (
          <div style={card}>
            <Field label="Session ID *">
              <input
                inputMode="numeric"
                placeholder="e.g., 123"
                value={sessionId}
                onChange={(e)=>setSessionId(e.target.value.replace(/\D/g,""))}
                style={input}
              />
            </Field>
            <div style={{ marginTop: 12 }}>
              <button style={btnPrimary} onClick={loadMeta} disabled={!sessionId}>Continue</button>
            </div>
          </div>
        )}

        {/* STEP 1: WIFI/GEO */}
        {step === STEP.WIFI_GEO && (
          <div style={card}>
            <div style={sectionH}>Background checks</div>
            <div style={grid3}>
              <Field label={`Public IP ${ip ? "✓" : ""}`}>
                <div style={{ display:"flex", gap:8 }}>
                  <input value={ip} readOnly style={input} />
                  <button style={btnGhost} onClick={refreshIp}>Refresh IP</button>
                </div>
              </Field>
              <Field label={`Latitude ${lat!=="" ? "✓" : ""}`}>
                <input value={lat} readOnly style={input} />
              </Field>
              <Field label={`Longitude ${lng!=="" ? "✓" : ""}`}>
                <div style={{ display:"flex", gap:8 }}>
                  <input value={lng} readOnly style={input} />
                  <button style={btnGhost} onClick={getLoc}>Use current location</button>
                </div>
              </Field>
            </div>
            <div style={{ fontSize:12, color:"#94a3b8", marginTop:6 }}>{geoMsg}</div>

            <div style={{ marginTop: 12, display:"flex", gap:8 }}>
              <button style={btnGhost} onClick={()=>setStep(STEP.PICK_SESSION)}>← Back</button>
              <button style={btnPrimary} onClick={runWifiGeoChecks} disabled={!canContinueWifi || loading}>
                {loading ? "Checking…" : "Check Wi-Fi & Geo"}
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: FACE */}
        {step === STEP.FACE && (
          <div style={card}>
            <div style={{ marginBottom: 8, color:"#94a3b8", fontSize:13 }}>
              Capture a selfie (only if the session requires FACE).
            </div>

            {!camOn && !selfieFile && (
              <button style={btnGhost} onClick={startCamera}>Start camera</button>
            )}

            <div style={{ marginBottom: 6, fontSize:12, color:"#64748b", minHeight:18 }}>{camMsg}</div>
            <div style={{ marginBottom: 8 }}>
              <video
                ref={videoRef}
                autoPlay
                muted
                playsInline
                style={{
                  width:"100%", height: "360px",
                  objectFit:"cover",
                  borderRadius: 10, border:"1px solid #334155", background:"#000",
                  display: camOn ? "block" : "none"
                }}
              />
            </div>

            {camOn && (
              <div style={{ display:"flex", gap:8 }}>
                <button style={btnPrimary} onClick={captureSelfie}>Capture</button>
                <button style={btnGhost} onClick={stopCamera}>Stop</button>
              </div>
            )}

            {selfieFile && (
              <div style={{ marginTop: 8, display:"flex", gap:12, alignItems:"center" }}>
                <span style={{ fontSize:13, color:"#94a3b8" }}>Selfie ready: {selfieFile.name}</span>
                <button style={btnGhost} onClick={() => {
                  setSelfieFile(null);
                  if (selfiePreview) URL.revokeObjectURL(selfiePreview);
                  setSelfiePreview("");
                }}>Retake</button>
              </div>
            )}
            {selfiePreview && (
              <img src={selfiePreview} alt="selfie preview"
                   style={{ marginTop:8, maxWidth:"100%", borderRadius:10, border:"1px solid #334155" }} />
            )}

            <div style={{ marginTop: 12, display:"flex", gap:8 }}>
              <button style={btnGhost} onClick={()=>setStep(STEP.WIFI_GEO)}>← Back</button>
              <button
                style={btnPrimary}
                onClick={runFaceCheck}
                disabled={!selfieFile || loading}
              >
                {loading ? "Checking…" : "Check face"}
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: QR */}
        {step === STEP.QR && (
          <div style={card}>
            <div style={{ marginBottom: 8, color:"#94a3b8", fontSize:13 }}>
              Scan the rotating QR on the teacher’s screen (or paste the token).
            </div>

            <div style={grid2}>
              <Field label="QR token">
                <input
                  placeholder="Paste if scanner not supported"
                  value={qrToken}
                  onChange={(e)=>setQrToken(e.target.value)}
                  style={input}
                />
              </Field>
              <Field label="Scanner">
                <div style={{ display:"flex", gap:8 }}>
                  <button style={btnGhost} onClick={startQrScan} disabled={scanning}>Scan now</button>
                  {scanning && <button style={btnGhost} onClick={stopQr}>Stop</button>}
                </div>
              </Field>
            </div>

            {scanning && (
              <video
                ref={qrVideoRef}
                autoPlay
                muted
                playsInline
                style={{ width:"100%", height:"320px", objectFit:"cover",
                         borderRadius: 10, border:"1px solid #334155", marginTop:8, background:"#000" }}
              />
            )}
            {scanErr && <div style={errorBox}>{scanErr}</div>}

            <div style={{ marginTop: 12, display:"flex", gap:8 }}>
              <button style={btnGhost} onClick={()=>setStep(STEP.FACE)}>← Back</button>
              <button
                style={btnPrimary}
                onClick={runQrCheckThenCommit}
                disabled={loading || !qrToken}
              >
                {loading ? "Submitting…" : "Verify & Submit"}
              </button>
            </div>
          </div>
        )}

        {step === STEP.DONE && (
          <div style={card}>
            <p style={{ margin:0, color:"#bbf7d0" }}>✅ Attendance marked. You can close this page.</p>
          </div>
        )}
      </div>
    </div>
  );
}

/* helpers/components */
function Field({ label, children }) {
  return (
    <div>
      <div style={lbl}>{label}</div>
      {children}
    </div>
  );
}

/** Renders server-provided check details */
function ChecksBreakdown({ checks }) {
  const Row = ({ label, ok, detail }) => (
    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
      <span style={{ width:70, color:"#cbd5e1" }}>{label}</span>
      <span style={{ width:8, height:8, borderRadius:999, background: ok ? "#22c55e" : "#ef4444" }} />
      <span style={{ color:"#94a3b8", fontSize:13 }}>{detail}</span>
    </div>
  );
  const face = checks?.FACE;
  const geo  = checks?.GEO;
  const wifi = checks?.WIFI;
  const qr   = checks?.QR;
  return (
    <div style={{ ...card, padding:10, marginTop:-4 }}>
      {wifi && <Row label="Wi-Fi" ok={!!wifi.ok} detail={wifi.ok ? "OK" : (wifi.reason || "Wi-Fi mismatch")} />}
      {geo && (
        <Row
          label="Geo"
          ok={!!geo.ok}
          detail={
            geo.ok
              ? "OK"
              : (geo.reason || (typeof geo.distanceMeters === "number"
                  ? `Outside geofence (${Math.round(geo.distanceMeters)}m)`
                  : "Outside geofence"))
          }
        />
      )}
      {face && <Row label="Face" ok={!!face.ok} detail={face.ok ? "OK" : (face.reason || "Face not match")} />}
      {qr && <Row label="QR" ok={!!qr.ok} detail={qr.ok ? "OK" : (qr.reason || "QR invalid/expired")} />}
    </div>
  );
}

/* styles */
const page = { minHeight:"100vh", background:"linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color:"#e2e8f0", padding:24 };
const wrap = { maxWidth:1100, margin:"0 auto" };
const head = { display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 };
const title = { margin:0, fontSize:24, fontWeight:800 };

const card = { background:"#111827", border:"1px solid #243244", borderRadius:14, padding:14, boxShadow:"0 10px 22px rgba(0,0,0,.35)", marginBottom:14 };
const grid2 = { display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 };
const grid3 = { display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10 };

const lbl = { display:"block", fontSize:13, color:"#cbd5e1", marginBottom:6 };
const input = { width:"100%", height:40, background:"#0b1220", border:"1px solid #2b3a55", color:"#e2e8f0", borderRadius:10, padding:"0 10px" };

const btnPrimary = { padding:"10px 14px", borderRadius:10, border:"none", background:"#2563eb", color:"white", fontWeight:800, cursor:"pointer" };
const btnGhost   = { padding:"10px 14px", borderRadius:10, border:"1px solid #334155", background:"#0b1220", color:"#cbd5e1", cursor:"pointer" };
const btnDanger  = { padding:"10px 14px", borderRadius:10, border:"1px solid #7f1d1d", background:"#450a0a", color:"#fecaca", cursor:"pointer" };

const sectionH = { marginTop: 10, marginBottom: 6, fontWeight: 800, fontSize: 14 };
const errorBox = { background:"#7f1d1d", color:"#fecaca", padding:"8px 10px", borderRadius:10, marginBottom:8, fontSize:13 };
const okBox    = { background:"#0b3b18", border:"1px solid #14532d", color:"#bbf7d0", padding:"8px 10px", borderRadius:10, marginBottom:8, fontSize:13 };
