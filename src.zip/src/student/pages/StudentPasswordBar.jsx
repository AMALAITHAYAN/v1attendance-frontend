import { useState } from "react";
import { getStudentPass, setStudentPass } from "../utils/studentAuth";

export default function StudentPasswordBar() {
  const [show, setShow] = useState(false);
  const [pwd, setPwd] = useState(getStudentPass());

  return (
    <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 12 }}>
      <input
        type={show ? "text" : "password"}
        placeholder="Student password"
        value={pwd}
        onChange={(e) => setPwd(e.target.value)}
        style={input}
      />
      <button style={btnGhost} onClick={() => setShow(s => !s)}>{show ? "Hide" : "Show"}</button>
      <button
        style={btnGhost}
        onClick={() => setStudentPass(pwd)}
        title="Save to headers for subsequent requests"
      >
        Save
      </button>
    </div>
  );
}

const input    = { width: 260, height: 40, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: "0 10px" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
