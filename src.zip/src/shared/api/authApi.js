// src/shared/api/authApi.js
import axios from "./axiosInstance";

/**
 * Normalize a role value to one of the allowed enums or null.
 */
function normalizeRole(val) {
  if (!val) return null;
  const up = String(val).toUpperCase();
  return ["SUPER_ADMIN", "TEACHER", "STUDENT"].includes(up) ? up : null;
}

/**
 * POST /api/auth/login
 * Works with either:
 *  - JSON: { message: "Login success", role: "TEACHER" }
 *  - Plain text: "Login success! Role: TEACHER"
 *  - JSON string (misconfigured server sending JSON as text)
 */
export async function login({ username, password }) {
  const res = await axios.post("/api/auth/login", { username, password });
  const data = res?.data;

  let role = null;
  let message = "";

  if (data && typeof data === "object") {
    // Proper JSON object
    role = normalizeRole(data.role);
    message = data.message ?? "";
  } else if (typeof data === "string") {
    const str = data.trim();

    // Try JSON-in-string first
    try {
      const parsed = JSON.parse(str);
      role = normalizeRole(parsed.role);
      message = parsed.message ?? str;
    } catch {
      // Fallback: parse "Role: X" from plain text
      const m = /Role:\s*(SUPER_ADMIN|TEACHER|STUDENT)/i.exec(str);
      role = m ? m[1].toUpperCase() : null;
      message = str;
    }
  }

  return { message, role };
}

/**
 * POST /api/auth/change-password
 */
export async function changePassword({ username, oldPassword, newPassword }) {
  const { data } = await axios.post("/api/auth/change-password", {
    username,
    oldPassword,
    newPassword,
  });
  return data; // e.g. "Password changed"
}

export async function changePasswordApi({ username, oldPassword, newPassword }) {
  if (!username || !oldPassword || !newPassword) {
    throw new Error("All fields are required");
  }
  const { data } = await axios.post("/api/auth/change-password", {
    username,
    oldPassword,
    newPassword,
  });
  return data; // "Password changed"
}
