import { useRef, useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { login } from "../api/authApi";

/* --- route by role --- */
const roleToRoute = (role) => {
  switch ((role || "").toUpperCase()) {
    case "SUPER_ADMIN":
    case "TEACHER":
      return "/admin";      // teacher UI lives under /admin
    case "STUDENT":
      return "/student";
    default:
      return "/login";
  }
};

export default function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const fromRef = useRef(location.state?.from || null);

  const [form, setForm] = useState({ username: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  /* One-time redirect if already logged in (no loops) */
  const didAutoRedirect = useRef(false);
  useEffect(() => {
    if (didAutoRedirect.current) return;
    didAutoRedirect.current = true;
    try {
      const teacherObj = JSON.parse(localStorage.getItem("attendance:user") || "null");
      const teacherPass = localStorage.getItem("attendance:teacherPass");
      const studentU = localStorage.getItem("attendance:studentUser");
      const studentP = localStorage.getItem("attendance:studentPass");
      if (teacherObj?.username && teacherPass) {
        navigate("/admin", { replace: true });
        return;
      }
      if (studentU && studentP) {
        navigate("/student", { replace: true });
        return;
      }
    } catch {
      /* ignore */
    }
  }, [navigate]);

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  /** Persist keys exactly as your admin code expects. */
  const persistRoleKeys = (role, username, password) => {
    const u = (username || "").trim().toLowerCase();

    // Clean up any legacy string that might have been saved at attendance:user
    // (your admin code parses JSON here).
    try {
      const raw = localStorage.getItem("attendance:user");
      if (raw && !raw.trim().startsWith("{")) {
        localStorage.removeItem("attendance:user");
      }
    } catch {}

    switch ((role || "").toUpperCase()) {
      case "TEACHER":
        // IMPORTANT: save JSON here (your admin UI expects JSON)
        localStorage.setItem("attendance:user", JSON.stringify({ username: u, role: "TEACHER" }));
        localStorage.setItem("attendance:teacherPass", password);
        break;

      case "SUPER_ADMIN":
        // Keep super-admin’s own keys…
        localStorage.setItem("attendance:adminUser", u);
        localStorage.setItem("attendance:adminPass", password);
        // …but also save teacher JSON + pass because the admin UI calls teacher endpoints.
        localStorage.setItem("attendance:user", JSON.stringify({ username: u, role: "TEACHER" }));
        localStorage.setItem("attendance:teacherPass", password);
        break;

      case "STUDENT":
        localStorage.setItem("attendance:studentUser", u);
        localStorage.setItem("attendance:studentPass", password);
        break;

      default:
        throw new Error("Unknown role from server");
    }

    localStorage.setItem("attendance:lastRole", (role || "").toUpperCase());
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");

    const username = form.username.trim();
    const password = form.password;

    if (!username || !password) {
      setError("Username and password are required.");
      return;
    }

    try {
      setLoading(true);
      const res = await login({ username, password }); // should return { role, message? }
      const role = res?.role;
      if (!role) throw new Error(res?.message || "Login response missing role");

      persistRoleKeys(role, username, password);

      const dest = fromRef.current || roleToRoute(role);
      navigate(dest, { replace: true });
    } catch (err) {
      const msg =
        err?.response?.status === 401
          ? "Invalid credentials"
          : err?.message || "Login failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={pageWrap}>
      <div style={backgroundPattern} />
      <div style={card}>
        <div style={headerSection}>
          <div style={iconContainer}>
            <span role="img" aria-label="graduation cap" style={headerIcon}>🎓</span>
          </div>
          <h1 style={title}>Attendance System</h1>
          <p style={subtitle}>Sign in to your account</p>
        </div>

        <form onSubmit={onSubmit} style={formStyles} noValidate>
          <div style={field}>
            <label style={label}>Email Address</label>
            <div style={inputContainer}>
              <input
                name="username"
                type="email"
                placeholder="you@school.edu"
                value={form.username}
                onChange={onChange}
                autoComplete="username"
                style={input}
                required
              />
            </div>
          </div>

          <div style={field}>
            <label style={label}>Password</label>
            <div style={inputContainer}>
              <input
                name="password"
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={form.password}
                onChange={onChange}
                autoComplete="current-password"
                style={{ ...input, paddingRight: 50 }}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                style={toggleBtn}
                aria-label={showPassword ? "Hide password" : "Show password"}
                title={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? "🙈" : "👁️"}
              </button>
            </div>
          </div>

          {error && (
            <div style={errorBox}>
              <span style={errorIcon}>⚠️</span>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              ...submitBtn,
              opacity: loading ? 0.7 : 1,
              transform: loading ? "scale(0.98)" : "scale(1)",
            }}
          >
            {loading ? (<><span style={loadingSpinner} />&nbsp;Signing in…</>) : (<>Sign In</>)}
          </button>
        </form>
      </div>
    </div>
  );
}

/* ---------- styles (unchanged from your version) ---------- */
const pageWrap = {
  minHeight: "100vh",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: 20,
  background: "linear-gradient(135deg, #000000 0%, #111111 50%, #000000 100%)",
  position: "relative",
  overflow: "hidden",
  fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
};
const backgroundPattern = {
  position: "absolute", inset: 0,
  backgroundImage: `
    radial-gradient(circle at 25% 25%, rgba(59,130,246,.15) 0%, transparent 50%),
    radial-gradient(circle at 75% 75%, rgba(147,51,234,.15) 0%, transparent 50%),
    radial-gradient(circle at 50% 50%, rgba(16,185,129,.1) 0%, transparent 70%)
  `,
  pointerEvents: "none",
};
const card = {
  width: "100%", maxWidth: 420, background: "rgba(0,0,0,.85)", backdropFilter: "blur(20px)",
  border: "1px solid rgba(255,255,255,.1)", padding: 40, borderRadius: 24,
  boxShadow: "0 25px 50px rgba(0,0,0,.5), 0 0 0 1px rgba(255,255,255,.05), inset 0 1px 0 rgba(255,255,255,.1)",
  position: "relative", zIndex: 1,
};
const headerSection = { textAlign: "center", marginBottom: 36 };
const iconContainer = {
  display: "inline-flex", alignItems: "center", justifyContent: "center",
  width: 70, height: 70,
  background: "linear-gradient(135deg, #3b82f6, #8b5cf6, #10b981)",
  borderRadius: 20, marginBottom: 20, boxShadow: "0 8px 20px rgba(59,130,246,.3)",
};
const headerIcon = { color: "#fff", filter: "drop-shadow(0 2px 4px rgba(0,0,0,.3))", fontSize: 32, lineHeight: 1 };
const title = {
  margin: 0, marginBottom: 8, fontSize: 32, fontWeight: 800,
  background: "linear-gradient(135deg, #fff, #e5e7eb, #d1d5db)",
  backgroundClip: "text", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
  letterSpacing: "-1px", textShadow: "0 2px 4px rgba(0,0,0,.3)",
};
const subtitle = { margin: 0, fontSize: 16, color: "#9ca3af", fontWeight: 500 };
const formStyles = { width: "100%" };
const field = { marginBottom: 24 };
const label = { display: "flex", alignItems: "center", fontSize: 14, fontWeight: 600, color: "#e5e7eb", marginBottom: 10 };
const inputContainer = { position: "relative", display: "flex", alignItems: "center" };
const input = {
  width: "100%", height: 52, background: "rgba(0,0,0,.6)", border: "1px solid rgba(255,255,255,.15)",
  outline: "none", color: "#fff", paddingLeft: 16, paddingRight: 16, borderRadius: 14,
  fontSize: 15, fontWeight: 500, transition: "all .3s cubic-bezier(.4,0,.2,1)", boxSizing: "border-box",
};
const toggleBtn = {
  position: "absolute", top: "50%", right: 14, transform: "translateY(-50%)",
  height: 36, width: 36, display: "flex", alignItems: "center", justifyContent: "center",
  borderRadius: 10, border: "none", background: "rgba(255,255,255,.1)", color: "#9ca3af",
  cursor: "pointer", transition: "all .2s ease", zIndex: 2,
};
const errorBox = {
  display: "flex", alignItems: "center", background: "rgba(239,68,68,.15)",
  border: "1px solid rgba(239,68,68,.3)", color: "#fca5a5", padding: "14px 18px",
  borderRadius: 14, margin: "20px 0", fontSize: 14, fontWeight: 500, backdropFilter: "blur(10px)",
};
const errorIcon = { marginRight: 10, flexShrink: 0 };
const submitBtn = {
  marginTop: 28, width: "100%", height: 52, borderRadius: 14,
  background: "linear-gradient(135deg, #3b82f6, #8b5cf6, #10b981)", color: "#fff",
  border: "none", fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center",
  justifyContent: "center", gap: 10, transition: "all .3s cubic-bezier(.4,0,.2,1)",
  boxShadow: "0 8px 20px rgba(59,130,246,.4)", letterSpacing: ".5px", textTransform: "uppercase", fontSize: 14,
};
const loadingSpinner = {
  width: 18, height: 18, border: "2px solid rgba(255,255,255,.3)", borderTop: "2px solid #fff",
  borderRadius: "50%", display: "inline-block", animation: "spin 1s linear infinite",
};

/* tiny global helpers */
(function addStyles() {
  if (typeof document === "undefined") return;
  const style = document.createElement("style");
  style.innerHTML = `
    @keyframes spin { 0% { transform: rotate(0deg) } 100% { transform: rotate(360deg) } }
    input:focus { border-color:#3b82f6 !important; box-shadow:0 0 0 3px rgba(59,130,246,.25) !important; background:rgba(0,0,0,.8)!important; }
    button:focus-visible { outline:2px solid #60a5fa; outline-offset:2px; }
    button[type="submit"]:hover:not(:disabled) { transform:translateY(-2px); box-shadow:0 12px 25px rgba(59,130,246,.5); background:linear-gradient(135deg,#2563eb,#7c3aed,#059669); }
    input:hover { border-color:rgba(255,255,255,.25); background:rgba(0,0,0,.7); }
    button[type="button"]:hover { background:rgba(59,130,246,.2); color:#fff; transform:translateY(-50%) scale(1.05); }
    button[type="submit"]:active { transform: translateY(-1px); }
  `;
  document.head.appendChild(style);
})();
