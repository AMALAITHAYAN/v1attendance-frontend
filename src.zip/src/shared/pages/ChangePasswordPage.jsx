// src/shared/pages/ChangePasswordPage.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { changePasswordApi } from "../api/authApi";

// localStorage keys used in your app:
// SUPER_ADMIN: attendance:adminUser / attendance:adminPass
// TEACHER:     attendance:user     / attendance:teacherPass
// STUDENT:     attendance:studentUser / attendance:studentPass

function getActiveRole() {
  if (localStorage.getItem("attendance:adminUser") && localStorage.getItem("attendance:adminPass")) {
    return "SUPER_ADMIN";
  }
  if (localStorage.getItem("attendance:user") && localStorage.getItem("attendance:teacherPass")) {
    return "TEACHER";
  }
  if (localStorage.getItem("attendance:studentUser") && localStorage.getItem("attendance:studentPass")) {
    return "STUDENT";
  }
  return null;
}

function currentUsernameForRole(role) {
  switch (role) {
    case "SUPER_ADMIN": return localStorage.getItem("attendance:adminUser") || "";
    case "TEACHER":     return localStorage.getItem("attendance:user") || "";
    case "STUDENT":     return localStorage.getItem("attendance:studentUser") || "";
    default:            return "";
  }
}

function setNewPasswordLocally(role, newPass) {
  switch (role) {
    case "SUPER_ADMIN": localStorage.setItem("attendance:adminPass", newPass); break;
    case "TEACHER":     localStorage.setItem("attendance:teacherPass", newPass); break;
    case "STUDENT":     localStorage.setItem("attendance:studentPass", newPass); break;
  }
}

export default function ChangePasswordPage() {
  const nav = useNavigate();
  const role = useMemo(getActiveRole, []);

  useEffect(() => {
    if (!role) nav("/login", { replace: true });
  }, [role, nav]);

  const [username, setUsername] = useState(currentUsernameForRole(role));
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);

  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setErr(""); setOk("");
    if (!username || !oldPassword || !newPassword || !confirm) {
      setErr("Please fill all fields."); return;
    }
    if (newPassword.length < 4) {
      setErr("New password must be at least 4 characters."); return;
    }
    if (newPassword !== confirm) {
      setErr("Passwords do not match."); return;
    }

    try {
      setLoading(true);
      await changePasswordApi({ username, oldPassword, newPassword });
      setNewPasswordLocally(role, newPassword);
      setOk("Password changed. You will use the new password next time.");
      setOldPassword(""); setNewPassword(""); setConfirm("");
    } catch (e) {
      setErr(e?.message || "Change password failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Change Password</h1>
          <div style={{ display:"flex", gap:8 }}>
            <button style={btnGhost} onClick={() => nav(-1)}>← Back</button>
          </div>
        </div>

        {err && <div style={errorBox}>{err}</div>}
        {ok && <div style={okBox}>{ok}</div>}

        <div style={card}>
          <div style={lbl}>Username</div>
          <input
            value={username}
            onChange={(e)=>setUsername(e.target.value)}
            style={input}
            placeholder="your username"
          />

          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginTop:10 }}>
            <div>
              <div style={lbl}>Current password</div>
              <input
                type={show ? "text" : "password"}
                value={oldPassword}
                onChange={(e)=>setOldPassword(e.target.value)}
                style={input}
                placeholder="current password"
              />
            </div>
            <div>
              <div style={lbl}>New password</div>
              <input
                type={show ? "text" : "password"}
                value={newPassword}
                onChange={(e)=>setNewPassword(e.target.value)}
                style={input}
                placeholder="new password"
              />
            </div>
          </div>

          <div style={{ marginTop:10 }}>
            <div style={lbl}>Confirm new password</div>
            <input
              type={show ? "text" : "password"}
              value={confirm}
              onChange={(e)=>setConfirm(e.target.value)}
              style={input}
              placeholder="confirm new password"
            />
          </div>

          <label style={{ display:"flex", alignItems:"center", gap:8, marginTop:8, color:"#94a3b8", fontSize:13 }}>
            <input type="checkbox" checked={show} onChange={(e)=>setShow(e.target.checked)} />
            Show passwords
          </label>

          <div style={{ marginTop:12 }}>
            <button style={btnPrimary} onClick={submit} disabled={loading}>
              {loading ? "Saving…" : "Change Password"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* styles */
const page  = { minHeight:"100vh", background:"linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color:"#e2e8f0", padding:24 };
const wrap  = { maxWidth:720, margin:"0 auto" };
const head  = { display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 };
const title = { margin:0, fontSize:24, fontWeight:800 };

const card  = { background:"#111827", border:"1px solid #243244", borderRadius:14, padding:14, boxShadow:"0 10px 22px rgba(0,0,0,.35)" };

const lbl   = { display:"block", fontSize:13, color:"#cbd5e1", marginBottom:6 };
const input = { width:"100%", height:40, background:"#0b1220", border:"1px solid #2b3a55", color:"#e2e8f0", borderRadius:10, padding:"0 10px" };

const btnPrimary = { padding:"10px 14px", borderRadius:10, border:"none", background:"#2563eb", color:"#fff", fontWeight:800, cursor:"pointer" };
const btnGhost   = { padding:"10px 14px", borderRadius:10, border:"1px solid #334155", background:"#0b1220", color:"#cbd5e1", cursor:"pointer" };

const errorBox = { background:"#7f1d1d", color:"#fecaca", padding:"8px 10px", borderRadius:10, marginBottom:8, fontSize:13 };
const okBox    = { background:"#0b3b18", border:"1px solid #14532d", color:"#bbf7d0", padding:"8px 10px", borderRadius:10, marginBottom:8, fontSize:13 };
