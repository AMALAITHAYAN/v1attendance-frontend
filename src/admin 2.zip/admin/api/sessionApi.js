import axios from "./axiosInstance";
import { teacherHeadersOrThrow } from "../utils/teacherAuth";

export async function startSession(payload) {
  const headers = teacherHeadersOrThrow();
  const res = await axios.post("/api/teacher/sessions/start", payload, { headers });
  return res.data; // Session
}

export async function stopSession(sessionId) {
  const headers = teacherHeadersOrThrow();
  const res = await axios.post(`/api/teacher/sessions/${sessionId}/stop`, null, { headers });
  return res.data; // updated Session
}

export async function fetchSessionSummary(sessionId) {
  const headers = teacherHeadersOrThrow();
  const res = await axios.get(`/api/teacher/sessions/${sessionId}/summary`, { headers });
  // { sessionId, present, total }
  return res.data;
}
