// src/admin/api/teacherReportApi.js
import axios from "./axiosInstance";                 // shared axios (has baseURL)
import { teacherHeadersOrThrow } from "../utils/teacherAuth";

/**
 * GET /api/teacher/reports/sessions?from&to
 * Returns: SessionBrief[]
 */
export async function fetchTeacherSessions(fromISO, toISO) {
  const { data } = await axios.get("/api/teacher/reports/sessions", {
    params: { from: fromISO, to: toISO },
    headers: { ...teacherHeadersOrThrow() },
  });
  return data;
}

/**
 * GET /api/teacher/reports/sessions/{id}/summary
 * Returns: { sessionId, present, total }
 */
export async function fetchTeacherSessionSummary(sessionId) {
  const { data } = await axios.get(
    `/api/teacher/reports/sessions/${sessionId}/summary`,
    { headers: { ...teacherHeadersOrThrow() } }
  );
  return data;
}
