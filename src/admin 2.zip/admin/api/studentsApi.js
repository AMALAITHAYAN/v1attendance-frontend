// src/admin/api/studentsApi.js
import axios from "axios";
import { teacherHeadersOrThrow } from "../utils/teacherAuth";

const BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:8080";
console.log("Axios baseURL →", BASE_URL);

/** Create a single student (multipart: JSON part + optional photo) */
export async function createStudentApi(jsonData, photoFile) {
  const fd = new FormData();
  fd.append("data", new Blob([JSON.stringify(jsonData)], { type: "application/json" }));
  if (photoFile) fd.append("photo", photoFile);

  const res = await axios.post(`${BASE_URL}/api/teacher/students`, fd, {
    headers: {
      ...teacherHeadersOrThrow(), // do NOT set Content-Type; browser sets it for FormData
    },
  });
  return res.data;
}

/** Bulk upload (.xlsx) */
export async function bulkUploadStudentsApi(xlsxFile) {
  const fd = new FormData();
  fd.append("file", xlsxFile);
  const res = await axios.post(`${BASE_URL}/api/teacher/students/bulk-upload`, fd, {
    headers: {
      ...teacherHeadersOrThrow(),
    },
  });
  return res.data;
}

/** Download CSV template */
export async function downloadStudentsTemplate() {
  const res = await axios.get(`${BASE_URL}/api/teacher/students/template`, {
    responseType: "blob",
    headers: { ...teacherHeadersOrThrow() },
  });
  const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "students_template.csv";
  a.click();
  URL.revokeObjectURL(url);
}

/* ---- Back-compat aliases so older imports compile ---- */
export const createStudent = createStudentApi;
export const bulkUploadStudents = bulkUploadStudentsApi;
export const downloadTemplate = downloadStudentsTemplate;
