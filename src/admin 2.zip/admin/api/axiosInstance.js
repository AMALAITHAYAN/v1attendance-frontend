// src/admin/api/axiosInstance.js
import axios from "axios";

/**
 * Teacher-scoped axios client.
 * Automatically attaches X-Auth-Username / X-Auth-Password
 * from localStorage (set via TeacherPasswordBar + login).
 */
const axiosInstance = axios.create({
  baseURL: process.env.REACT_APP_API_BASE_URL || "http://localhost:8080",
});

// (debug) see the base URL in devtools
try { console.log("Axios (admin) baseURL →", axiosInstance.defaults.baseURL); } catch {}

axiosInstance.interceptors.request.use((config) => {
  try {
    const raw = localStorage.getItem("attendance:user");
    if (raw) {
      const user = JSON.parse(raw);
      if (user?.username) {
        config.headers["X-Auth-Username"] = user.username;
      }
    }
    // password saved by TeacherPasswordBar
    const teacherPass = localStorage.getItem("attendance:teacherPass");
    if (teacherPass) {
      config.headers["X-Auth-Password"] = teacherPass;
    }
  } catch {
    /* ignore */
  }
  return config;
});

// Optional: normalize server errors -> Error(message)
axiosInstance.interceptors.response.use(
  (res) => res,
  (err) => {
    const message =
      err?.response?.data?.message ||
      err?.response?.data?.error ||
      (typeof err?.response?.data === "string" ? err.response.data : "") ||
      err?.message ||
      "Request failed";
    const e = new Error(message);
    e.status = err?.response?.status;
    throw e;
  }
);

export default axiosInstance;
