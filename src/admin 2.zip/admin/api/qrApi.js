import axios from "./axiosInstance";
import { teacherHeadersOrThrow } from "../utils/teacherAuth";

export async function fetchCurrentQrToken(sessionId) {
  const headers = teacherHeadersOrThrow();
  const res = await axios.get(`/api/teacher/qrs/${sessionId}/current-token`, { headers });
  // Controller returns a plain string token
  return typeof res.data === "string" ? res.data : String(res.data);
}
