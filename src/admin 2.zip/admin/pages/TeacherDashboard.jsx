// src/admin/pages/TeacherDashboard.jsx
import { Link, useNavigate } from "react-router-dom";
import { useCallback } from "react";

export default function TeacherDashboard() {
  const navigate = useNavigate();

  const logout = useCallback(() => {
    localStorage.removeItem("attendance:user");
    localStorage.removeItem("attendance:lastRole");
    navigate("/login", { replace: true });
  }, [navigate]);

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Teacher Dashboard</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button type="button" style={btnDanger} onClick={logout}>Logout</button>
          </div>
        </div>

        {/* Phase 2 — Start Session */}
        <div style={card}>
          <div style={{ marginBottom: 10 }}>
            <div style={badge}>Phase 2</div>
            <h3 style={cardH3}>Start Session</h3>
            <p style={muted}>Plan a session window with conflict checks.</p>
          </div>
          {/* use Link instead of navigate() */}
          <Link to="/admin/start-session" style={btnPrimary} role="button">
            Start Session
          </Link>
        </div>

        {/* Roster (Students) */}
        <div style={card}>
          <div style={{ marginBottom: 10 }}>
            <div style={badge}>Roster</div>
            <h3 style={cardH3}>Manage Students</h3>
            <p style={muted}>Create students and bulk upload (.xlsx).</p>
          </div>
          <Link to="/admin/students" style={btnGhost} role="button">
            Open Roster
          </Link>
        </div>

        {/* Reports */}
        <div style={card}>
          <div style={{ marginBottom: 10 }}>
            <div style={badge}>Phase 6</div>
            <h3 style={cardH3}>Reports</h3>
            <p style={muted}>View your sessions by date range and see per-session summaries.</p>
          </div>
          <Link to="/admin/reports" style={btnPrimary} role="button">
            Open Reports
          </Link>
        </div>
      </div>
    </div>
  );
}

/* styles (unchanged) */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 900, margin: "0 auto" };
const head = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 };
const title = { margin: 0, fontSize: 26, fontWeight: 800 };

const card = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 16, boxShadow: "0 10px 22px rgba(0,0,0,.35)", maxWidth: 560, marginBottom: 14 };
const badge = { display: "inline-block", padding: "2px 8px", fontSize: 12, borderRadius: 999, background: "#1e293b", border: "1px solid #334155", color: "#cbd5e1" };
const cardH3 = { margin: "8px 0 6px", fontSize: 18, fontWeight: 800 };
const muted = { margin: 0, color: "#94a3b8", fontSize: 13 };

const btnPrimary = { display: "inline-block", padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 18px rgba(37,99,235,.35)", textDecoration: "none" };
const btnGhost   = { display: "inline-block", padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer", textDecoration: "none" };
const btnDanger  = { padding: "10px 14px", borderRadius: 10, border: "1px solid #7f1d1d", background: "#450a0a", color: "#fecaca", cursor: "pointer" };
