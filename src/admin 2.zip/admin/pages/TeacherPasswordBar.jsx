// src/admin/pages/TeacherPasswordBar.jsx
import { useEffect, useState } from "react";
import { getTeacherUser, getTeacherPass, setTeacherPass } from "../utils/teacherAuth";

export default function TeacherPasswordBar() {
  const user = getTeacherUser();
  const [show, setShow] = useState(false);
  const [pass, setPass] = useState(getTeacherPass());

  useEffect(() => setPass(getTeacherPass()), []);

  const onChange = (e) => {
    const v = e.target.value;
    setPass(v);
    // auto-save so API headers are never missing
    setTeacherPass(v ?? "");
  };

  const save = () => setTeacherPass(pass ?? "");

  return (
    <div style={bar}>
      <div style={{ fontSize: 13, color: "#94a3b8" }}>Teacher</div>
      <div style={{ fontWeight: 700 }}>{user?.username || "-"}</div>
      <div style={{ flex: 1 }} />
      <input
        type={show ? "text" : "password"}
        placeholder="password"
        value={pass}
        onChange={onChange}
        style={input}
      />
      <button style={btnGhost} onClick={() => setShow((s) => !s)}>{show ? "Hide" : "Show"}</button>
      <button style={btnPrimary} onClick={save}>Save</button>
    </div>
  );
}

const bar = {
  display: "flex", gap: 10, alignItems: "center",
  background: "#0b1220", border: "1px solid #243244",
  borderRadius: 12, padding: 10, marginBottom: 12
};
const input = {
  width: 340, height: 40, background: "#0b1220",
  border: "1px solid #2b3a55", color: "#e2e8f0",
  borderRadius: 10, padding: "0 10px"
};
const btnPrimary = {
  padding: "10px 14px", borderRadius: 10, border: "none",
  background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer"
};
const btnGhost = {
  padding: "10px 14px", borderRadius: 10,
  border: "1px solid #334155", background: "#0b1220",
  color: "#cbd5e1", cursor: "pointer"
};
