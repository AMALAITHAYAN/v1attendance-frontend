import { useState } from "react";
import { manualMarkAttendance } from "../api/attendanceApi";

export default function ManualMarkDialog({ open, onClose, sessionId, onSuccess }) {
  const [studentId, setStudentId] = useState("");
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  if (!open) return null;

  const submit = async (e) => {
    e.preventDefault();
    setErr("");
    if (!studentId) { setErr("Student ID is required"); return; }
    try {
      setLoading(true);
      const saved = await manualMarkAttendance({ sessionId, studentId, reason });
      onSuccess?.(saved);
      setStudentId(""); setReason("");
      onClose?.();
    } catch (e2) {
      setErr(e2.message || "Manual mark failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={backdrop} onMouseDown={onClose}>
      <div style={modal} onMouseDown={(e) => e.stopPropagation()}>
        <h3 style={{ margin: "0 0 8px", fontWeight: 800 }}>Manual Mark</h3>
        <p style={{ marginTop: 0, color: "#94a3b8", fontSize: 13 }}>
          Override checks and mark a student present for this session.
        </p>

        {err && <p style={errorBox}>{err}</p>}

        <form onSubmit={submit}>
          <div style={{ marginBottom: 8 }}>
            <div style={lbl}>Student ID *</div>
            <input
              inputMode="numeric"
              value={studentId}
              onChange={(e) => setStudentId(e.target.value.replace(/\D/g, ""))}
              placeholder="e.g., 101"
              style={input}
            />
          </div>
          <div style={{ marginBottom: 12 }}>
            <div style={lbl}>Reason (optional)</div>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g., device issue"
              style={textarea}
            />
          </div>

          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
            <button type="button" style={btnGhost} onClick={onClose}>Cancel</button>
            <button type="submit" style={btnPrimary} disabled={loading}>
              {loading ? "Saving…" : "Save"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* styles */
const backdrop = { position: "fixed", inset: 0, background: "rgba(2,6,23,.6)", display: "grid", placeItems: "center", zIndex: 50 };
const modal = { width: "100%", maxWidth: 480, background: "#0b1220", border: "1px solid #243244", borderRadius: 14, padding: 14, boxShadow: "0 20px 40px rgba(0,0,0,.5)" };
const lbl = { display: "block", fontSize: 13, color: "#cbd5e1", marginBottom: 6 };
const input = { width: "100%", height: 40, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: "0 10px" };
const textarea = { width: "100%", minHeight: 90, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: 10, fontSize: 14 };
const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginBottom: 8, fontSize: 13 };
