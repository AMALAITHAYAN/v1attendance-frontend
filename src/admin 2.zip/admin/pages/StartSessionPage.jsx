// src/admin/pages/StartSessionPage.jsx
import { useEffect, useMemo, useState, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { startSession } from "../api/sessionApi";
import TeacherPasswordBar from "./TeacherPasswordBar";

export default function StartSessionPage() {
  const navigate = useNavigate();

  // defaults: next 60 mins
  const now = useMemo(() => new Date(), []);
  const plus60 = useMemo(() => new Date(now.getTime() + 60 * 60 * 1000), [now]);

  const [form, setForm] = useState({
    year: "", department: "", className: "", subject: "",
    startTime: toLocal(now), endTime: toLocal(plus60),
    latitude: "", longitude: "", radiusMeters: 50,
    networkSignature: "", wifiPolicy: "PUBLIC_IP",
    qrIntervalSeconds: 5,
  });
  const [flow, setFlow] = useState({ WIFI: true, GEO: true, FACE: true, QR: true });

  const [publicIp, setPublicIp] = useState("");
  const [geoMsg, setGeoMsg] = useState("");
  const [loading, setLoading] = useState(false);
  const [ok, setOk] = useState("");
  const [err, setErr] = useState("");

  // Fetch public IP on mount
  useEffect(() => {
    let mounted = true;
    (async () => {
      const ip = await getPublicIp();
      if (mounted) setPublicIp(ip);
    })();
    return () => { mounted = false; };
  }, []);

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };
  const setNumber = (name, value) => {
    setForm((f) => ({ ...f, [name]: value === "" ? "" : Number(value) }));
  };

  const useCurrentLocation = useCallback(() => {
    if (!navigator.geolocation) { setGeoMsg("Geolocation is not supported."); return; }
    setGeoMsg("Fetching location…");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        setForm((f) => ({ ...f, latitude, longitude }));
        setGeoMsg(`Location set (±${Math.round(accuracy)}m)`);
      },
      (e) => setGeoMsg(`Location error: ${e.message}`),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }, []);

  const refreshIp = useCallback(async () => {
    const ip = await getPublicIp();
    setPublicIp(ip);
  }, []);

  const onSubmit = async (e) => {
    e.preventDefault();
    setErr(""); setOk("");

    if (!form.year || !form.department || !form.className || !form.subject) {
      setErr("Please fill year, department, class and subject."); return;
    }
    if (new Date(form.endTime) <= new Date(form.startTime)) {
      setErr("End time must be after start time."); return;
    }

    try {
      setLoading(true);
      const payload = {
        year: form.year.trim(),
        department: form.department.trim(),
        className: form.className.trim(),
        subject: form.subject.trim(),
        startTime: toApi(form.startTime),
        endTime: toApi(form.endTime),
        qrIntervalSeconds: Number(form.qrIntervalSeconds) || 5,
        networkSignature: form.networkSignature || null,
        wifiPolicy: form.wifiPolicy,
        latitude: form.latitude === "" ? null : Number(form.latitude),
        longitude: form.longitude === "" ? null : Number(form.longitude),
        radiusMeters: form.radiusMeters === "" ? null : Number(form.radiusMeters),
        flow: ["WIFI","GEO","FACE","QR"].filter((k) => flow[k]),
        publicIp: publicIp || null,
      };

      const session = await startSession(payload);
      setOk("Session started successfully.");
      navigate(`/admin/active-session/${session.id}`, { replace: true });
    } catch (e2) {
      if (e2.status === 409) setErr(e2.message || "Conflict: overlapping session");
      else setErr(e2.message || "Failed to start session");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Start Session</h1>
          <div style={{ display: "flex", gap: 8 }}>
            {/* Use Link for navigation; buttons can be swallowed by forms */}
            <Link to="/admin" style={btnGhost} role="button">← Dashboard</Link>
          </div>
        </div>

        <TeacherPasswordBar />

        {err && <p style={errorBox}>{err}</p>}
        {ok && <p style={okBox}>{ok}</p>}

        <form onSubmit={onSubmit} style={cardPad}>
          <div style={grid4}>
            <Field label="Year *"><input style={input} name="year" value={form.year} onChange={onChange} placeholder="1 / 2 / 3 / 4" /></Field>
            <Field label="Department *"><input style={input} name="department" value={form.department} onChange={onChange} placeholder="CSE" /></Field>
            <Field label="Class *"><input style={input} name="className" value={form.className} onChange={onChange} placeholder="A" /></Field>
            <Field label="Subject *"><input style={input} name="subject" value={form.subject} onChange={onChange} placeholder="Maths" /></Field>
          </div>

          <div style={grid2}>
            <Field label="Start *"><input type="datetime-local" style={input} name="startTime" value={form.startTime} onChange={onChange} /></Field>
            <Field label="End *"><input type="datetime-local" style={input} name="endTime" value={form.endTime} onChange={onChange} /></Field>
          </div>

          <div style={sectionH}>Validation Flow</div>
          <div style={chips}>
            {["WIFI","GEO","FACE","QR"].map((k) => (
              <label key={k} style={chip(flow[k])}>
                <input type="checkbox" checked={flow[k]} onChange={(e)=>setFlow((f)=>({ ...f, [k]: e.target.checked }))} />
                <span style={{ marginLeft: 6 }}>{k}</span>
              </label>
            ))}
          </div>

          <div style={sectionH}>Wi-Fi Policy</div>
          <div style={grid3}>
            <Field label="Policy">
              <select name="wifiPolicy" value={form.wifiPolicy} onChange={onChange} style={input}>
                <option value="PUBLIC_IP">PUBLIC_IP</option>
                <option value="NETWORK_SIGNATURE">NETWORK_SIGNATURE</option>
                <option value="BOTH">BOTH</option>
              </select>
            </Field>
            <Field label="Network Signature (optional)">
              <input style={input} name="networkSignature" value={form.networkSignature} onChange={onChange} placeholder="e.g., SSID hash" />
            </Field>
            <Field label="QR Interval (sec)">
              <input style={input} type="number" min="1" name="qrIntervalSeconds" value={form.qrIntervalSeconds} onChange={(e)=>setNumber("qrIntervalSeconds", e.target.value)} />
            </Field>
          </div>

          {/* Public IP display */}
          <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 12, color: "#94a3b8" }}>
              Detected Public IP: <strong style={{ color: "#e2e8f0" }}>{publicIp || "…"}</strong>
            </span>
            <button type="button" style={btnGhost} onClick={refreshIp}>Refresh IP</button>
          </div>

          <div style={sectionH}>Geofence (optional)</div>
          <div style={grid3}>
            <Field label="Latitude"><input style={input} name="latitude" value={form.latitude} onChange={onChange} placeholder="e.g., 12.9716" /></Field>
            <Field label="Longitude"><input style={input} name="longitude" value={form.longitude} onChange={onChange} placeholder="e.g., 77.5946" /></Field>
            <Field label="Radius (meters)"><input style={input} type="number" min="1" name="radiusMeters" value={form.radiusMeters} onChange={(e)=>setNumber("radiusMeters", e.target.value)} /></Field>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}>
            <button type="button" style={btnGhost} onClick={useCurrentLocation}>Use current location</button>
            <span style={{ fontSize: 12, color: "#94a3b8" }}>{geoMsg}</span>
          </div>

          <button type="submit" style={btnPrimary} disabled={loading}>
            {loading ? "Starting…" : "Start Session"}
          </button>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }) { return (<div><div style={lbl}>{label}</div>{children}</div>); }
function toLocal(d) { const pad=(n)=>String(n).padStart(2,"0"); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function toApi(localVal) { return localVal.length===16 ? `${localVal}:00` : localVal; }

/* styles */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 980, margin: "0 auto" };
const head = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 };
const title = { margin: 0, fontSize: 24, fontWeight: 800 };

const cardPad = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 12, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };

const grid2 = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 };
const grid3 = { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 };
const grid4 = { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 };

const lbl = { display: "block", fontSize: 13, color: "#cbd5e1", marginBottom: 6 };
const input = { width: "100%", height: 40, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: "0 10px" };

const sectionH = { marginTop: 10, marginBottom: 6, fontWeight: 800, fontSize: 14 };
const chips = { display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 6 };
const chip = (active) => ({ display: "inline-flex", alignItems: "center", padding: "6px 10px", borderRadius: 999, background: active ? "#052e16" : "#1f2937", color: active ? "#bbf7d0" : "#cbd5e1", border: "1px solid #334155", fontSize: 12, cursor: "pointer" });

const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginBottom: 8, fontSize: 13 };
const okBox = { background: "#0b3b18", border: "1px solid #14532d", color: "#bbf7d0", padding: "8px 10px", borderRadius: 10, marginBottom: 8, fontSize: 13 };

const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer", textDecoration: "none", display: "inline-block" };

// -------- helper to fetch client public IP (ipify) --------
async function getPublicIp() {
  try {
    const res = await fetch("https://api.ipify.org?format=json");
    const data = await res.json();
    return data?.ip || "";
  } catch {
    return "";
  }
}
