import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getTeacher, updateTeacher } from "../api/adminApi";
import { getAdminUser } from "../utils/saAuth";
import AdminPasswordBar from "./AdminPasswordBar";

export default function EditTeacherPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const user = getAdminUser();
  useEffect(() => { if (!user) navigate("/login", { replace: true }); }, [user, navigate]);

  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    name: "", gender: "", subjects: "", phoneNumber: "", idNumber: "", gmailId: "",
    newPassword: "",
  });
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const t = await getTeacher(id);
        setForm({
          name: t.name || "",
          gender: t.gender || "",
          subjects: Array.isArray(t.subjects) ? t.subjects.join(", ") : "",
          phoneNumber: t.phoneNumber || "",
          idNumber: t.idNumber || "",
          gmailId: t.gmailId || "",
          newPassword: "",
        });
      } catch (e) { setErr(e.message || "Failed to load teacher"); }
      finally { setLoading(false); }
    })();
  }, [id]);

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setMsg(""); setErr("");
    const body = {
      name: form.name.trim(),
      gender: form.gender || null,
      subjects: form.subjects.split(",").map((s) => s.trim()).filter(Boolean),
      phoneNumber: form.phoneNumber.trim() || null,
      idNumber: form.idNumber.trim() || null,
      newPassword: form.newPassword?.trim() || null,
    };
    if (!body.name) { setErr("Name is required."); return; }
    try {
      await updateTeacher(id, body);
      setMsg("Saved!");
      setForm((f) => ({ ...f, newPassword: "" }));
    } catch (e2) { setErr(e2.message || "Update failed"); }
  };

  if (loading) return <div style={{ padding: 24, color: "#e2e8f0" }}>Loading…</div>;

  return (
    <div style={page}>
      <div style={wrap}>
        <div style={head}>
          <h1 style={title}>Edit Teacher</h1>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={btnGhost} onClick={() => navigate("/superadmin/teachers")}>← Teachers</button>
            <button style={btnGhost} onClick={() => navigate("/superadmin")}>Dashboard</button>
          </div>
        </div>

        <AdminPasswordBar />

        <form onSubmit={submit} style={card}>
          <div style={grid}>
            <Field label="Name *"><input style={input} name="name" value={form.name} onChange={onChange} /></Field>
            <Field label="Gender">
              <select style={input} name="gender" value={form.gender} onChange={onChange}>
                <option value="">— Select —</option>
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </Field>
            <Field label="Subjects * (comma separated)" span>
              <input style={input} name="subjects" value={form.subjects} onChange={onChange} />
            </Field>
            <Field label="Phone"><input style={input} name="phoneNumber" value={form.phoneNumber} onChange={onChange} /></Field>
            <Field label="ID Number"><input style={input} name="idNumber" value={form.idNumber} onChange={onChange} /></Field>
            <Field label="Gmail ID (login)" ><input style={{ ...input, background: "#0b1220aa" }} value={form.gmailId} readOnly /></Field>
            <Field label="Reset Password (optional)"><input style={input} name="newPassword" value={form.newPassword} onChange={onChange} /></Field>
          </div>

          {err && <p style={errorBox}>{err}</p>}
          {msg && <p style={okBox}>{msg}</p>}

          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 10 }}>
            <button type="button" style={btnGhost} onClick={() => navigate("/superadmin/teachers")}>Cancel</button>
            <button type="submit" style={btnPrimary}>Save</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children, span }) {
  return (
    <div style={{ gridColumn: span ? "1 / -1" : "auto" }}>
      <label style={lbl}>{label}</label>
      {children}
    </div>
  );
}

/* styles */
const page = { minHeight: "100vh", background: "linear-gradient(180deg,#0b1220 0%, #0f172a 60%, #0b1220 100%)", color: "#e2e8f0", padding: 24 };
const wrap = { maxWidth: 900, margin: "0 auto" };
const head = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 };
const title = { margin: 0, fontSize: 24, fontWeight: 800 };
const card = { background: "#111827", border: "1px solid #243244", borderRadius: 14, padding: 16, boxShadow: "0 10px 22px rgba(0,0,0,.35)" };
const grid = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 };
const lbl = { display: "block", fontSize: 13, color: "#cbd5e1", marginBottom: 6 };
const input = { width: "100%", height: 40, background: "#0b1220", border: "1px solid #2b3a55", color: "#e2e8f0", borderRadius: 10, padding: "8px 10px" };
const btnPrimary = { padding: "10px 14px", borderRadius: 10, border: "none", background: "#2563eb", color: "white", fontWeight: 800, cursor: "pointer", boxShadow: "0 8px 18px rgba(37,99,235,.35)" };
const btnGhost = { padding: "10px 14px", borderRadius: 10, border: "1px solid #334155", background: "#0b1220", color: "#cbd5e1", cursor: "pointer" };
const errorBox = { background: "#7f1d1d", color: "#fecaca", padding: "8px 10px", borderRadius: 10, marginTop: 6, fontSize: 13 };
const okBox = { background: "#0b3b18", border: "1px solid #14532d", color: "#bbf7d0", padding: "8px 10px", borderRadius: 10, marginTop: 6, fontSize: 13 };
