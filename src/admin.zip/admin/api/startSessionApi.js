const BASE_URL = 'http://localhost:8080';

export async function startSession(formData, username, password) {
  const response = await fetch(`${BASE_URL}/api/teacher/sessions/start`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Auth-Username': username,
      'X-Auth-Password': password,
    },
    body: JSON.stringify(formData),
  });

  if (!response.ok) {
    const errorText = await response.text();
    const error = new Error(errorText);
    error.status = response.status;
    throw error;
  }
  return response.json();
}

export async function fetchCurrentQrToken(sessionId, username, password) {
  const response = await fetch(`${BASE_URL}/api/teacher/qrs/${sessionId}/current-token`, {
    method: 'GET',
    headers: {
      'X-Auth-Username': username,
      'X-Auth-Password': password,
    },
  });
  if (!response.ok) {
    const errorText = await response.text();
    const error = new Error(errorText);
    error.status = response.status;
    throw error;
  }
  return response.text();
}
