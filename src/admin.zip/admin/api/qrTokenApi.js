export async function fetchCurrentQrToken(sessionId, username, password) {
  const response = await fetch(`/api/teacher/qrs/${sessionId}/current-token`, {
    method: 'GET',
    headers: {
      'X-Auth-Username': username,
      'X-Auth-Password': password,
    },
  });
  if (!response.ok) {
    const errorText = await response.text();
    const error = new Error(errorText);
    error.status = response.status;
    throw error;
  }
  return response.text();  // returns JWT token string
}
