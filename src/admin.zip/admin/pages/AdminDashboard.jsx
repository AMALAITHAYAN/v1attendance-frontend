import React from 'react';
import { Link } from 'react-router-dom';

export default function AdminDashboard() {
  return (
    <div style={{ padding: 20, maxWidth: 600, margin: 'auto' }}>
      <h1>Teacher/Admin Dashboard</h1>
      <nav style={{ marginTop: 20 }}>
        <ul>
          <li>
            <Link to="/admin/start-session">Start Session</Link>
          </li>
          {/* Add more admin links as needed */}
        </ul>
      </nav>
    </div>
  );
}
