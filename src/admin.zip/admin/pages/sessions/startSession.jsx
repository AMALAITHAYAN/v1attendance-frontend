import React, { useState } from 'react';
import { startSession } from '../../api/startSessionApi';

const initialFormData = {
  year: '',
  department: '',
  className: '',
  subject: '',
  startTime: '',
  endTime: '',
  radiusMeters: '',
  qrIntervalSeconds: 5,
  flow: [],
};

export default function StartSession() {
  const [formData, setFormData] = useState(initialFormData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Use auth provider or context in production
  const username = process.env.REACT_APP_TEACHER_USERNAME || 'teacher_username';
  const password = process.env.REACT_APP_TEACHER_PASSWORD || 'teacher_password';

  const handleChange = (e) => {
    const { name, value, type, selectedOptions } = e.target;
    if (type === 'select-multiple') {
      const selected = Array.from(selectedOptions).map((opt) => opt.value);
      setFormData((prev) => ({ ...prev, [name]: selected }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const validateForm = () => {
    if (
      !formData.year ||
      !formData.department ||
      !formData.className ||
      !formData.subject ||
      !formData.startTime ||
      !formData.endTime
    ) {
      setError('Please fill in all required fields.');
      return false;
    }
    if (new Date(formData.endTime) <= new Date(formData.startTime)) {
      setError('End time must be after start time.');
      return false;
    }
    return true;
  };

  // Ensure datetime-local fields include seconds (add ':00' if missing)
  const normalizeDateTimeLocal = (dtStr) => {
    if (!dtStr) return dtStr;
    return dtStr.length === 16 ? dtStr + ':00' : dtStr;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    if (!validateForm()) return;
    setLoading(true);

    const payload = {
      ...formData,
      startTime: normalizeDateTimeLocal(formData.startTime),
      endTime: normalizeDateTimeLocal(formData.endTime),
      radiusMeters: formData.radiusMeters ? parseFloat(formData.radiusMeters) : null,
      qrIntervalSeconds: formData.qrIntervalSeconds ? Number(formData.qrIntervalSeconds) : 5,
      flow: formData.flow.length > 0 ? formData.flow : undefined,
    };

    try {
      await startSession(payload, username, password);
      window.location.href = '/admin/active-session';
    } catch (err) {
      if (err.status === 409) {
        setError(`Conflict Error: ${err.message}`);
      } else {
        setError(`Error: ${err.message}`);
      }
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: 600, margin: 'auto' }} noValidate>
      <h2>Start Session</h2>
      {error && (
        <div role="alert" style={{ color: 'red', marginBottom: 10 }}>
          {error}
        </div>
      )}

      <label htmlFor="year">Year *</label>
      <input id="year" name="year" value={formData.year} onChange={handleChange} required />

      <label htmlFor="department">Department *</label>
      <input id="department" name="department" value={formData.department} onChange={handleChange} required />

      <label htmlFor="className">Class Name *</label>
      <input id="className" name="className" value={formData.className} onChange={handleChange} required />

      <label htmlFor="subject">Subject *</label>
      <input id="subject" name="subject" value={formData.subject} onChange={handleChange} required />

      <label htmlFor="startTime">Start Time *</label>
      <input
        id="startTime"
        type="datetime-local"
        name="startTime"
        value={formData.startTime}
        onChange={handleChange}
        required
      />

      <label htmlFor="endTime">End Time *</label>
      <input
        id="endTime"
        type="datetime-local"
        name="endTime"
        value={formData.endTime}
        onChange={handleChange}
        required
      />

      <label htmlFor="radiusMeters">Radius (meters)</label>
      <input
        id="radiusMeters"
        type="number"
        name="radiusMeters"
        value={formData.radiusMeters}
        onChange={handleChange}
      />

      <label htmlFor="qrIntervalSeconds">QR Interval (seconds)</label>
      <input
        id="qrIntervalSeconds"
        type="number"
        min="1"
        name="qrIntervalSeconds"
        value={formData.qrIntervalSeconds}
        onChange={handleChange}
      />

      <label htmlFor="flow" style={{ marginTop: 10 }}>
        Validation Flow (hold Ctrl to select multiple)
      </label>
      <select
        id="flow"
        name="flow"
        multiple
        value={formData.flow}
        onChange={handleChange}
        size={4}
        style={{ width: '100%' }}
      >
        <option value="WIFI">WIFI</option>
        <option value="GEO">GEO</option>
        <option value="FACE">FACE</option>
        <option value="QR">QR</option>
      </select>

      <button type="submit" disabled={loading} style={{ marginTop: 15 }}>
        {loading ? 'Starting...' : 'Start Session'}
      </button>
    </form>
  );
}
