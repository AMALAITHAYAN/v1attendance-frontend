import React, { useEffect, useState, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';

// Converts base64 string to Uint8Array
function base64ToUint8Array(base64) {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Generates QR payload by concatenating secret bytes hex + interval number hex
function generateQrPayload(secretBytes, intervalNumber) {
  const intervalHex = intervalNumber.toString(16).padStart(8, '0');
  const secretHex = Array.from(secretBytes).map((b) => b.toString(16).padStart(2, '0')).join('');
  return secretHex + intervalHex;
}

/**
 * ActiveSession Component
 * Props:
 * - auth: { username: string, password: string }
 */
export default function ActiveSession({ auth }) {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [qrData, setQrData] = useState('');

  const username = auth?.username || '';
  const password = auth?.password || '';

  const intervalRef = useRef(null);

  useEffect(() => {
    async function fetchActiveSession() {
      try {
        const response = await fetch('http://localhost:8080/api/teacher/sessions/active', {
          headers: {
            'X-Auth-Username': username,
            'X-Auth-Password': password,
          },
        });

        if (!response.ok) {
          const text = await response.text();
          throw new Error(text || 'Failed to fetch active session');
        }
        const data = await response.json();
        setSession(data);
        return data;
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    }

    fetchActiveSession().then((data) => {
      if (!data) return;

      const qrSecret = data.qrSecret;
      const qrIntervalSecs = data.qrIntervalSeconds || 5;

      if (!qrSecret) {
        setQrData('No QR secret available');
        setLoading(false);
        return;
      }

      const secretBytes = base64ToUint8Array(qrSecret);

      function updateQr() {
        const nowSec = Math.floor(Date.now() / 1000);
        const intervalNum = Math.floor(nowSec / qrIntervalSecs);
        const payload = generateQrPayload(secretBytes, intervalNum);
        setQrData(payload);
      }

      updateQr();
      intervalRef.current = setInterval(updateQr, qrIntervalSecs * 1000);
      setLoading(false);
    });

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [username, password]);

  if (loading) return <p>Loading active session...</p>;
  if (error) return <p style={{ color: 'red' }}>Error: {error}</p>;
  if (!session) return <p>No active session found.</p>;

  return (
    <div style={{ maxWidth: 600, margin: 'auto', textAlign: 'center' }}>
      <h2>Active Session Details</h2>
      <p><strong>Year:</strong> {session.year}</p>
      <p><strong>Department:</strong> {session.department}</p>
      <p><strong>Class:</strong> {session.className}</p>
      <p><strong>Subject:</strong> {session.subject}</p>
      <p><strong>Start Time:</strong> {new Date(session.startTime).toLocaleString()}</p>
      <p><strong>End Time:</strong> {new Date(session.endTime).toLocaleString()}</p>

      <div style={{ margin: '20px 0' }}>
        <h3>Scan this QR code to mark attendance</h3>
        {qrData ? (
          <QRCodeSVG value={qrData} size={256} />
        ) : (
          <p>Generating QR Code...</p>
        )}
        <p style={{ marginTop: 10, fontSize: 12, color: '#666' }}>
          QR refreshes every {session.qrIntervalSeconds || 5} seconds
        </p>
      </div>
    </div>
  );
}
